import { type NextRequest, NextResponse } from "next/server"

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "7647879137:AAFiDcAzEjVlaaNTBA8zNpw4uJysFTmUzOc"

interface TelegramUpdate {
  update_id: number
  message?: {
    message_id: number
    from: {
      id: number
      is_bot: boolean
      first_name: string
      last_name?: string
      username?: string
    }
    chat: {
      id: number
      type: string
    }
    date: number
    text?: string
  }
  callback_query?: {
    id: string
    from: {
      id: number
      first_name: string
      username?: string
    }
    data: string
  }
}

// Функция для отправки ответа пользователю
async function sendMessage(chatId: number, text: string, replyMarkup?: any) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        reply_markup: replyMarkup,
      }),
    })

    return await response.json()
  } catch (error) {
    console.error("Error sending message:", error)
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    const update: TelegramUpdate = await request.json()
    console.log("Received webhook update:", update)

    // Обработка обычных сообщений
    if (update.message) {
      const { message } = update
      const chatId = message.chat.id
      const text = message.text || ""
      const user = message.from

      console.log(`Message from ${user.first_name} (${user.username}): ${text}`)

      // Команда /start
      if (text.startsWith("/start")) {
        const welcomeMessage = `
👋 <b>Добро пожаловать в Astrum!</b>

🎯 Создавайте профессиональные ТЗ и брифы
📋 Делитесь документами с клиентами
🚀 Управляйте проектами эффективно

Нажмите кнопку ниже, чтобы открыть приложение:
        `.trim()

        const keyboard = {
          inline_keyboard: [
            [
              {
                text: "🚀 Открыть Astrum",
                web_app: {
                  url: "https://tma.astrum.app", // Замените на ваш домен
                },
              },
            ],
            [
              {
                text: "ℹ️ Помощь",
                callback_data: "help",
              },
              {
                text: "📞 Поддержка",
                callback_data: "support",
              },
            ],
          ],
        }

        await sendMessage(chatId, welcomeMessage, keyboard)
      }
      // Команда /help
      else if (text === "/help") {
        const helpMessage = `
📖 <b>Помощь по Astrum</b>

<b>Основные функции:</b>
• Создание ТЗ и брифов
• Отправка документов клиентам
• Управление проектами
• Шаблоны для быстрого старта

<b>Как использовать:</b>
1. Откройте приложение через кнопку
2. Создайте новый документ
3. Настройте дизайн и содержание
4. Отправьте клиенту через бота

<b>Нужна помощь?</b> Напишите /support
        `.trim()

        await sendMessage(chatId, helpMessage)
      }
      // Команда /support
      else if (text === "/support") {
        const supportMessage = `
🆘 <b>Поддержка Astrum</b>

📧 Email: support@astrum.app
💬 Telegram: @astrum_support
🌐 Сайт: https://astrum.app

<b>Часто задаваемые вопросы:</b>
• Как создать ТЗ? - Откройте приложение и выберите "Создать"
• Как отправить документ? - Используйте кнопку "Поделиться"
• Проблемы с доступом? - Проверьте интернет-соединение

Мы ответим в течение 24 часов! 🚀
        `.trim()

        await sendMessage(chatId, supportMessage)
      }
      // Неизвестная команда
      else {
        const unknownMessage = `
❓ Не понимаю эту команду.

Доступные команды:
/start - Начать работу
/help - Помощь
/support - Поддержка

Или откройте приложение через кнопку ниже:
        `.trim()

        const keyboard = {
          inline_keyboard: [
            [
              {
                text: "🚀 Открыть Astrum",
                web_app: {
                  url: "https://tma.astrum.app",
                },
              },
            ],
          ],
        }

        await sendMessage(chatId, unknownMessage, keyboard)
      }
    }

    // Обработка callback запросов (нажатия на inline кнопки)
    if (update.callback_query) {
      const { callback_query } = update
      const chatId = callback_query.from.id
      const data = callback_query.data

      if (data === "help") {
        const helpMessage = `
📖 <b>Помощь по Astrum</b>

<b>Основные функции:</b>
• Создание ТЗ и брифов
• Отправка документов клиентам
• Управление проектами
• Шаблоны для быстрого старта

<b>Как использовать:</b>
1. Откройте приложение через кнопку
2. Создайте новый документ
3. Настройте дизайн и содержание
4. Отправьте клиенту через бота
        `.trim()

        await sendMessage(chatId, helpMessage)
      } else if (data === "support") {
        const supportMessage = `
🆘 <b>Поддержка Astrum</b>

📧 Email: support@astrum.app
💬 Telegram: @astrum_support
🌐 Сайт: https://astrum.app

Мы ответим в течение 24 часов! 🚀
        `.trim()

        await sendMessage(chatId, supportMessage)
      }

      // Отвечаем на callback query
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerCallbackQuery`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          callback_query_id: callback_query.id,
        }),
      })
    }

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

// Для настройки webhook
export async function GET() {
  try {
    const webhookUrl = `${process.env.VERCEL_URL || "https://your-domain.vercel.app"}/api/webhook`

    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
      }),
    })

    const data = await response.json()

    return NextResponse.json({
      webhook_set: data.ok,
      webhook_url: webhookUrl,
      response: data,
    })
  } catch (error) {
    return NextResponse.json(
      {
        error: "Failed to set webhook",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
