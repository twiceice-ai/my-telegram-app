import { type NextRequest, NextResponse } from "next/server"
import { put } from "@vercel/blob"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File
    const type = formData.get("type") as string

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file size (max 4.5MB for Vercel Blob)
    if (file.size > 4.5 * 1024 * 1024) {
      return NextResponse.json({ error: "File too large. Max size is 4.5MB" }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = {
      background: ["image/jpeg", "image/png", "image/webp"],
      logo: ["image/jpeg", "image/png", "image/webp", "image/svg+xml"],
      banner: ["image/jpeg", "image/png", "image/webp"],
      media: ["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"],
      question_image: ["image/jpeg", "image/png", "image/webp"],
    }

    const validTypes = allowedTypes[type as keyof typeof allowedTypes] || allowedTypes.media
    if (!validTypes.includes(file.type)) {
      return NextResponse.json({ error: `Invalid file type. Allowed types: ${validTypes.join(", ")}` }, { status: 400 })
    }

    // Generate filename with timestamp
    const timestamp = Date.now()
    const extension = file.name.split(".").pop()
    const filename = `${type}/${timestamp}.${extension}`

    // Upload to Vercel Blob
    const blob = await put(filename, file, {
      access: "public",
    })

    return NextResponse.json({
      url: blob.url,
      filename: filename,
      size: file.size,
      type: file.type,
    })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json(
      {
        error: "Upload failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
