import { type NextRequest, NextResponse } from "next/server"

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "7647879137:AAFiDcAzEjVlaaNTBA8zNpw4uJysFTmUzOc"
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`

interface SendRequest {
  username: string
  document_id: string
  document_title: string
  document_type: "tz" | "brief"
  document_url: string
}

// Функция для получения информации о пользователе по username
async function getUserByUsername(username: string) {
  try {
    // В Telegram Bot API нет прямого способа получить user_id по username
    // Поэтому мы используем альтернативный подход через поиск в чатах
    // Или можем сохранять соответствие username -> user_id в базе данных

    // Для демонстрации возвращаем заглушку
    // В реальном приложении здесь должна быть логика поиска пользователя
    return null
  } catch (error) {
    console.error("Error getting user by username:", error)
    return null
  }
}

// Функция для отправки сообщения пользователю
async function sendMessageToUser(userId: number, message: string, replyMarkup?: any) {
  try {
    const response = await fetch(`${TELEGRAM_API_URL}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: userId,
        text: message,
        parse_mode: "HTML",
        reply_markup: replyMarkup,
      }),
    })

    const data = await response.json()
    return { success: response.ok, data }
  } catch (error) {
    console.error("Error sending message:", error)
    return { success: false, error }
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: SendRequest = await request.json()
    const { username, document_id, document_title, document_type, document_url } = body

    // Валидация данных
    if (!username || !document_id || !document_title || !document_url) {
      return NextResponse.json({ error: "Отсутствуют обязательные поля" }, { status: 400 })
    }

    // Проверяем инициализационные данные Telegram
    const initData = request.headers.get("X-Telegram-Init-Data")
    if (!initData) {
      return NextResponse.json({ error: "Неавторизованный запрос" }, { status: 401 })
    }

    // Получаем информацию о пользователе
    const user = await getUserByUsername(username)

    // Для демонстрации используем фиксированный chat_id
    // В реальном приложении здесь должен быть реальный user_id получателя
    const recipientChatId = 123456789 // Замените на реальный chat_id

    // Формируем сообщение
    const typeLabel = document_type === "tz" ? "Техническое задание" : "Бриф"
    const message = `
🎯 <b>Новый документ от Astrum</b>

📋 <b>Тип:</b> ${typeLabel}
📝 <b>Название:</b> ${document_title}

Нажмите кнопку ниже, чтобы открыть документ:
    `.trim()

    // Создаем inline клавиатуру с кнопкой для открытия документа
    const replyMarkup = {
      inline_keyboard: [
        [
          {
            text: `📖 Открыть ${document_type === "tz" ? "ТЗ" : "Бриф"}`,
            url: document_url,
          },
        ],
        [
          {
            text: "🚀 Открыть Astrum",
            url: "https://t.me/your_bot_username/app", // Замените на ваш бот
          },
        ],
      ],
    }

    // Отправляем сообщение
    const result = await sendMessageToUser(recipientChatId, message, replyMarkup)

    if (result.success) {
      // Обновляем статус документа на "active" в базе данных
      // Здесь должен быть код для обновления статуса в БД

      return NextResponse.json({
        success: true,
        message: "Документ успешно отправлен",
        telegram_response: result.data,
      })
    } else {
      return NextResponse.json(
        {
          error: "Ошибка отправки через Telegram",
          details: result.data || result.error,
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Error in send API:", error)
    return NextResponse.json(
      {
        error: "Внутренняя ошибка сервера",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

// Webhook для обработки входящих сообщений от бота
export async function GET(request: NextRequest) {
  try {
    // Получаем информацию о боте
    const response = await fetch(`${TELEGRAM_API_URL}/getMe`)
    const data = await response.json()

    return NextResponse.json({
      bot_info: data,
      webhook_url: `${request.nextUrl.origin}/api/webhook`,
      status: "Bot API connected",
    })
  } catch (error) {
    return NextResponse.json(
      {
        error: "Failed to connect to Telegram Bot API",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
