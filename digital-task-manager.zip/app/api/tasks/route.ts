import { type NextRequest, NextResponse } from "next/server"
import { safeQuery, initializeDatabase } from "@/lib/db"

export async function GET() {
  try {
    // Initialize database tables if needed
    await initializeDatabase()

    const { data, error } = await safeQuery("SELECT * FROM tasks ORDER BY created_at DESC")

    if (error) {
      return NextResponse.json({ error: "Failed to fetch tasks", details: error }, { status: 500 })
    }

    return NextResponse.json({ tasks: data || [] })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json(
      { error: "Internal server error", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description, status = "pending", priority = "medium", due_date } = body

    if (!title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 })
    }

    const { data, error } = await safeQuery(
      "INSERT INTO tasks (title, description, status, priority, due_date) VALUES ($1, $2, $3, $4, $5) RETURNING *",
      [title, description, status, priority, due_date],
    )

    if (error) {
      return NextResponse.json({ error: "Failed to create task", details: error }, { status: 500 })
    }

    return NextResponse.json({ task: data?.[0] }, { status: 201 })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json(
      { error: "Internal server error", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
