import { NextResponse } from "next/server"
import { testConnection } from "@/lib/db"

export async function GET() {
  console.log("Health check starting...")

  try {
    // Check environment variables
    const envCheck = {
      DATABASE_URL: !!process.env.DATABASE_URL,
      POSTGRES_URL: !!process.env.POSTGRES_URL,
      DATABASE_URL_UNPOOLED: !!process.env.DATABASE_URL_UNPOOLED,
      NODE_ENV: process.env.NODE_ENV,
    }

    console.log("Environment variables:", envCheck)

    // Test database connection
    const dbTest = await testConnection()

    const healthStatus = {
      status: "ok",
      timestamp: new Date().toISOString(),
      environment: envCheck,
      database: dbTest,
      version: "1.0.0",
    }

    console.log("Health check result:", healthStatus)

    return NextResponse.json(healthStatus, {
      status: dbTest.success ? 200 : 500,
    })
  } catch (error) {
    console.error("Health check failed:", error)

    return NextResponse.json(
      {
        status: "error",
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : "Health check failed",
        name: error instanceof Error ? error.name : "UnknownError",
      },
      { status: 500 },
    )
  }
}
