import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

// Функция для валидации Telegram initData
function validateTelegramData(initData: string): boolean {
  // В разработке разрешаем пустые initData
  if (process.env.NODE_ENV === "development") {
    return true
  }
  return initData.length > 0
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    console.log("API: Fetching document with id:", id)

    // Проверяем авторизацию
    const initData = request.headers.get("X-Telegram-Init-Data") || ""
    if (!validateTelegramData(initData)) {
      console.log("API: Unauthorized request")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    try {
      const documents = await sql`
        SELECT * FROM documents 
        WHERE id = ${id}
        LIMIT 1
      `

      if (documents.length === 0) {
        return NextResponse.json({ error: "Document not found" }, { status: 404 })
      }

      console.log("API: Document found:", documents[0].id)

      return NextResponse.json({
        document: documents[0],
        timestamp: new Date().toISOString(),
      })
    } catch (queryError) {
      console.error("API: Query execution failed:", queryError)
      return NextResponse.json(
        {
          error: "Query execution failed",
          details: queryError instanceof Error ? queryError.message : "Unknown query error",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("API: General error in GET /api/documents/[id]:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch document",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    console.log("API: Deleting document with id:", id)

    // Проверяем авторизацию
    const initData = request.headers.get("X-Telegram-Init-Data") || ""
    if (!validateTelegramData(initData)) {
      console.log("API: Unauthorized DELETE request")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    try {
      // Сначала проверяем, существует ли документ
      const existingDoc = await sql`
        SELECT id, title FROM documents 
        WHERE id = ${id}
        LIMIT 1
      `

      if (existingDoc.length === 0) {
        return NextResponse.json({ error: "Document not found" }, { status: 404 })
      }

      // Удаляем документ
      const result = await sql`
        DELETE FROM documents 
        WHERE id = ${id}
        RETURNING id, title
      `

      if (result.length === 0) {
        return NextResponse.json({ error: "Failed to delete document" }, { status: 500 })
      }

      console.log("API: Document deleted successfully:", result[0].id)

      return NextResponse.json({
        message: "Document deleted successfully",
        deleted_document: result[0],
        timestamp: new Date().toISOString(),
      })
    } catch (queryError) {
      console.error("API: Delete query failed:", queryError)
      return NextResponse.json(
        {
          error: "Delete operation failed",
          details: queryError instanceof Error ? queryError.message : "Unknown query error",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("API: General error in DELETE /api/documents/[id]:", error)
    return NextResponse.json(
      {
        error: "Failed to delete document",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const body = await request.json()
    const { title, content, design_config, status } = body

    console.log("API: Updating document with id:", id)

    // Проверяем авторизацию
    const initData = request.headers.get("X-Telegram-Init-Data") || ""
    if (!validateTelegramData(initData)) {
      console.log("API: Unauthorized PUT request")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    try {
      // Обновляем документ
      const result = await sql`
        UPDATE documents 
        SET 
          title = COALESCE(${title}, title),
          content = COALESCE(${content ? JSON.stringify(content) : null}, content),
          design_config = COALESCE(${design_config ? JSON.stringify(design_config) : null}, design_config),
          status = COALESCE(${status}, status),
          updated_at = NOW()
        WHERE id = ${id}
        RETURNING *
      `

      if (result.length === 0) {
        return NextResponse.json({ error: "Document not found" }, { status: 404 })
      }

      console.log("API: Document updated successfully:", result[0].id)

      return NextResponse.json({
        document: result[0],
        message: "Document updated successfully",
        timestamp: new Date().toISOString(),
      })
    } catch (queryError) {
      console.error("API: Update query failed:", queryError)
      return NextResponse.json(
        {
          error: "Update operation failed",
          details: queryError instanceof Error ? queryError.message : "Unknown query error",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("API: General error in PUT /api/documents/[id]:", error)
    return NextResponse.json(
      {
        error: "Failed to update document",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
