import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

// Функция для валидации Telegram initData
function validateTelegramData(initData: string): boolean {
  // В разработке разрешаем пустые initData
  if (process.env.NODE_ENV === "development") {
    return true
  }
  // В реальном приложении здесь должна быть проверка подписи
  // используя секретный ключ бота
  return initData.length > 0
}

// Функция для инициализации таблицы documents
async function ensureDocumentsTable() {
  try {
    console.log("API: Checking if documents table exists...")

    // Проверяем существование таблицы
    const tableExists = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'documents'
      );
    `

    if (!tableExists[0]?.exists) {
      console.log("API: Documents table doesn't exist, creating...")

      // Создаем UUID extension
      await sql`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`

      // Создаем таблицу с новой структурой
      await sql`
        CREATE TABLE documents (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id BIGINT NOT NULL,
          title VARCHAR(100) NOT NULL,
          type VARCHAR(10) NOT NULL CHECK (type IN ('tz', 'brief')),
          status VARCHAR(10) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'completed')),
          design_config JSONB,
          content JSONB,
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
      `

      // Создаем индексы
      await sql`CREATE INDEX IF NOT EXISTS idx_documents_user_id ON documents(user_id)`
      await sql`CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status)`
      await sql`CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(type)`
      await sql`CREATE INDEX IF NOT EXISTS idx_documents_updated_at ON documents(updated_at)`

      // Добавляем тестовые данные
      await sql`
        INSERT INTO documents (user_id, title, type, status, content, design_config) VALUES
        (123456789, 'ТЗ для лендинга интернет-магазина', 'tz', 'active', 
         '{"description": "Создать современный лендинг для продажи товаров", "steps": [{"id": "step-1", "title": "Шаг 1", "blocks": [{"id": "block-1", "type": "description", "title": "Описание проекта", "content": {"description": "Создать современный лендинг для продажи товаров"}}]}]}',
         '{"background": {"type": "color", "value": "#f8fafc"}, "font": "Inter"}'),
        (123456789, 'Бриф для ребрендинга компании', 'brief', 'draft',
         '{"questions": [{"id": "1", "title": "Опишите текущую ситуацию", "type": "text", "required": true}]}',
         '{"background": {"type": "color", "value": "#fef3c7"}, "font": "Roboto"}'),
        (123456789, 'ТЗ мобильного приложения', 'tz', 'completed',
         '{"description": "Разработка iOS/Android приложения", "steps": [{"id": "step-1", "title": "Шаг 1", "blocks": [{"id": "block-1", "type": "tasks", "title": "Что нужно сделать", "content": {"tasks": ["UI/UX дизайн", "Разработка", "Тестирование"]}}]}]}',
         '{"background": {"type": "color", "value": "#dcfce7"}, "font": "Open Sans"}')
        ON CONFLICT DO NOTHING
      `

      console.log("API: Documents table created successfully with test data")
    } else {
      console.log("API: Documents table already exists")
    }
  } catch (error) {
    console.error("API: Error ensuring documents table:", error)
    throw error
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status") || "all"
    const type = searchParams.get("type") || "all"
    const sort = searchParams.get("sort") || "newest"
    const userId = searchParams.get("user_id")

    console.log("API: Fetching documents with params:", { status, type, sort, userId })

    // Проверяем авторизацию
    const initData = request.headers.get("X-Telegram-Init-Data") || ""
    if (!validateTelegramData(initData)) {
      console.log("API: Unauthorized request")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Убеждаемся, что таблица существует
    await ensureDocumentsTable()

    // Выполняем запрос
    let documents

    try {
      if (status === "all" && type === "all") {
        // Все документы
        if (sort === "newest") {
          documents = await sql`
            SELECT * FROM documents 
            ORDER BY updated_at DESC
            LIMIT 50
          `
        } else {
          documents = await sql`
            SELECT * FROM documents 
            ORDER BY updated_at ASC
            LIMIT 50
          `
        }
      } else if (status !== "all" && type !== "all") {
        // Фильтр по статусу и типу
        if (sort === "newest") {
          documents = await sql`
            SELECT * FROM documents 
            WHERE status = ${status} AND type = ${type}
            ORDER BY updated_at DESC
            LIMIT 50
          `
        } else {
          documents = await sql`
            SELECT * FROM documents 
            WHERE status = ${status} AND type = ${type}
            ORDER BY updated_at ASC
            LIMIT 50
          `
        }
      } else if (status !== "all") {
        // Только по статусу
        if (sort === "newest") {
          documents = await sql`
            SELECT * FROM documents 
            WHERE status = ${status}
            ORDER BY updated_at DESC
            LIMIT 50
          `
        } else {
          documents = await sql`
            SELECT * FROM documents 
            WHERE status = ${status}
            ORDER BY updated_at ASC
            LIMIT 50
          `
        }
      } else if (type !== "all") {
        // Только по типу
        if (sort === "newest") {
          documents = await sql`
            SELECT * FROM documents 
            WHERE type = ${type}
            ORDER BY updated_at DESC
            LIMIT 50
          `
        } else {
          documents = await sql`
            SELECT * FROM documents 
            WHERE type = ${type}
            ORDER BY updated_at ASC
            LIMIT 50
          `
        }
      } else {
        // Fallback
        if (sort === "newest") {
          documents = await sql`
            SELECT * FROM documents 
            ORDER BY updated_at DESC
            LIMIT 50
          `
        } else {
          documents = await sql`
            SELECT * FROM documents 
            ORDER BY updated_at ASC
            LIMIT 50
          `
        }
      }

      console.log("API: Query executed successfully, found documents:", documents?.length || 0)
    } catch (queryError) {
      console.error("API: Query execution failed:", queryError)
      return NextResponse.json(
        {
          error: "Query execution failed",
          details: queryError instanceof Error ? queryError.message : "Unknown query error",
        },
        { status: 500 },
      )
    }

    // Убедимся, что documents это массив
    const documentsArray = Array.isArray(documents) ? documents : []

    console.log("API: Returning documents:", documentsArray.length)

    return NextResponse.json({
      documents: documentsArray,
      count: documentsArray.length,
      timestamp: new Date().toISOString(),
      filters: { status, type, sort, userId },
    })
  } catch (error) {
    console.error("API: General error in GET /api/documents:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch documents",
        details: error instanceof Error ? error.message : "Unknown error",
        stack: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, type, content, design_config, user_id } = body

    console.log("API: Creating document:", { title, type, user_id })

    // Проверяем авторизацию
    const initData = request.headers.get("X-Telegram-Init-Data") || ""
    if (!validateTelegramData(initData)) {
      console.log("API: Unauthorized POST request")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Валидация данных
    if (!title || !type) {
      console.log("API: Missing required fields")
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    if (!["tz", "brief"].includes(type)) {
      console.log("API: Invalid document type")
      return NextResponse.json({ error: "Invalid document type" }, { status: 400 })
    }

    // Убеждаемся, что таблица существует
    await ensureDocumentsTable()

    // Используем fallback user_id для разработки
    const finalUserId = user_id || 123456789

    try {
      const result = await sql`
        INSERT INTO documents (
          title, 
          type, 
          content, 
          design_config, 
          user_id, 
          status,
          created_at,
          updated_at
        ) VALUES (
          ${title},
          ${type},
          ${JSON.stringify(content || {})},
          ${JSON.stringify(design_config || {})},
          ${finalUserId},
          'draft',
          NOW(),
          NOW()
        ) RETURNING *
      `

      console.log("API: Document created successfully:", result[0]?.id)

      return NextResponse.json(
        {
          document: result[0],
          message: "Document created successfully",
        },
        { status: 201 },
      )
    } catch (insertError) {
      console.error("API: Insert error:", insertError)
      return NextResponse.json(
        {
          error: "Failed to insert document",
          details: insertError instanceof Error ? insertError.message : "Unknown insert error",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("API: General error in POST /api/documents:", error)
    return NextResponse.json(
      {
        error: "Failed to create document",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
