"use client"

import { useState, useEffect } from "react"
import { DocumentList } from "@/components/DocumentList"
import { CreateDocument } from "@/components/CreateDocument"
import { OpenByLink } from "@/components/OpenByLink"
import { useTelegram } from "@/components/providers/TelegramProvider"
import { FileText, Plus, Link, User } from "lucide-react"

type Tab = "documents" | "create" | "open"

export default function Page() {
  const [activeTab, setActiveTab] = useState<Tab>("documents")
  const { user, isReady, webApp } = useTelegram()

  useEffect(() => {
    if (webApp) {
      const handleBackButton = () => {
        if (activeTab !== "documents") {
          setActiveTab("documents")
        } else {
          webApp.close()
        }
      }

      webApp.BackButton.onClick(handleBackButton)

      if (activeTab !== "documents") {
        webApp.BackButton.show()
      } else {
        webApp.BackButton.hide()
      }

      // Обработчик смены вкладки
      const handleTabChange = (event: CustomEvent) => {
        setActiveTab(event.detail)
      }

      window.addEventListener("changeTab", handleTabChange as EventListener)

      return () => {
        window.removeEventListener("changeTab", handleTabChange as EventListener)
        if (webApp) {
          webApp.BackButton.offClick(handleBackButton)
        }
      }
    }
  }, [activeTab, webApp])

  if (!isReady) {
    return (
      <div className="telegram-viewport flex items-center justify-center">
        <div className="text-center px-6">
          <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-white border-t-transparent"></div>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Загрузка Astrum</h2>
          <p className="text-sm text-gray-600">Инициализация Telegram WebApp...</p>
        </div>
      </div>
    )
  }

  const tabs = [
    { id: "documents" as Tab, label: "Документы", icon: FileText },
    { id: "create" as Tab, label: "Создать", icon: Plus },
    { id: "open" as Tab, label: "Открыть", icon: Link },
  ]

  const handleTabChange = (tab: Tab) => {
    setActiveTab(tab)
    webApp?.HapticFeedback?.selectionChanged()
  }

  return (
    <div className="telegram-viewport">
      {/* Mobile Header */}
      <div className="mobile-header">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold text-sm">A</span>
          </div>
          <div className="min-w-0">
            <h1 className="text-lg font-bold text-gray-900 truncate">Astrum</h1>
            <p className="text-xs text-gray-600">ТЗ и Брифы</p>
          </div>
        </div>

        {user && (
          <div className="flex items-center space-x-2 flex-shrink-0">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-gray-900 truncate max-w-20">{user.first_name}</p>
              {user.username && <p className="text-xs text-gray-500 truncate max-w-20">@{user.username}</p>}
            </div>
            {user.photo_url ? (
              <img
                src={user.photo_url || "/placeholder.svg"}
                alt="Avatar"
                className="w-8 h-8 rounded-full border border-gray-200"
              />
            ) : (
              <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                <User className="h-4 w-4 text-gray-500" />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile Content */}
      <div className="mobile-content-with-airbar">
        {activeTab === "documents" && <DocumentList />}
        {activeTab === "create" && <CreateDocument />}
        {activeTab === "open" && <OpenByLink />}
      </div>

      {/* Bottom AirBar Navigation */}
      <div className="mobile-airbar">
        {tabs.map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              className={`mobile-airbar-tab ${activeTab === tab.id ? "active" : ""}`}
            >
              <div className="flex flex-col items-center">
                <Icon className="h-5 w-5 mb-1" />
                <span className="text-xs">{tab.label}</span>
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}
