"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { FileText, Calendar, Share, Trash2, ChevronDown, Plus, AlertCircle } from "lucide-react"
import { useTelegram } from "@/components/providers/TelegramProvider"
import { ShareModal } from "@/components/ShareModal"

interface Document {
  id: string
  title: string
  type: "tz" | "brief"
  status: "draft" | "active" | "completed" | "rejected"
  updated_at: string
  preview_image?: string
  is_template: boolean
}

type StatusFilter = "all" | "active" | "completed" | "draft" | "templates"
type TypeFilter = "all" | "tz" | "brief"
type SortOrder = "newest" | "oldest"

export function DocumentList() {
  const [documents, setDocuments] = useState<Document[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("active")
  const [typeFilter, setTypeFilter] = useState<TypeFilter>("all")
  const [sortOrder, setSortOrder] = useState<SortOrder>("newest")
  const [shareModalOpen, setShareModalOpen] = useState(false)
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null)
  const { user, webApp, initData } = useTelegram()

  useEffect(() => {
    fetchDocuments()
  }, [statusFilter, typeFilter, sortOrder])

  const fetchDocuments = async () => {
    try {
      setLoading(true)
      setError(null)

      console.log("Client: Starting fetch with filters:", { statusFilter, typeFilter, sortOrder })

      const params = new URLSearchParams({
        status: statusFilter,
        type: typeFilter,
        sort: sortOrder,
        user_id: user?.id?.toString() || "123456789",
      })

      console.log("Client: Making request to:", `/api/documents?${params}`)

      const response = await fetch(`/api/documents?${params}`, {
        method: "GET",
        headers: {
          "X-Telegram-Init-Data": initData || "",
          "Content-Type": "application/json",
        },
      })

      console.log("Client: Response status:", response.status)

      if (!response.ok) {
        const errorData = await response.json()
        console.error("Client: API error response:", errorData)
        throw new Error(errorData.error || `HTTP ${response.status}`)
      }

      const data = await response.json()
      console.log("Client: Received data:", data)

      if (data.documents && Array.isArray(data.documents)) {
        setDocuments(data.documents)
        console.log("Client: Set documents:", data.documents.length)
      } else {
        console.warn("Client: Invalid documents data:", data)
        setDocuments([])
      }
    } catch (error) {
      console.error("Client: Error fetching documents:", error)
      setError(error instanceof Error ? error.message : "Неизвестная ошибка")
      setDocuments([])
      webApp?.showAlert(
        "Ошибка загрузки документов: " + (error instanceof Error ? error.message : "Неизвестная ошибка"),
      )
    } finally {
      setLoading(false)
    }
  }

  const handleShare = (doc: Document, event: React.MouseEvent) => {
    event.stopPropagation()
    setSelectedDocument(doc)
    setShareModalOpen(true)
    webApp?.HapticFeedback?.impactOccurred("light")
  }

  const handleDelete = async (doc: Document, event: React.MouseEvent) => {
    event.stopPropagation()
    if (!webApp) return

    // Показываем подтверждение удаления
    webApp.showPopup(
      {
        title: "Удаление документа",
        message: `Вы уверены, что хотите удалить "${doc.title}"? Это действие нельзя отменить.`,
        buttons: [
          { id: "cancel", type: "cancel", text: "Отмена" },
          { id: "delete", type: "destructive", text: "Удалить" },
        ],
      },
      async (buttonId) => {
        if (buttonId === "delete") {
          try {
            webApp.HapticFeedback?.impactOccurred("medium")

            const response = await fetch(`/api/documents/${doc.id}`, {
              method: "DELETE",
              headers: {
                "X-Telegram-Init-Data": initData || "",
                "Content-Type": "application/json",
              },
            })

            if (response.ok) {
              webApp.HapticFeedback?.notificationOccurred("success")
              webApp.showAlert("Документ успешно удален")
              // Обновляем список документов
              fetchDocuments()
            } else {
              const errorData = await response.json()
              throw new Error(errorData.error || "Ошибка удаления")
            }
          } catch (error) {
            console.error("Delete error:", error)
            webApp.HapticFeedback?.notificationOccurred("error")
            webApp.showAlert(
              "Ошибка при удалении документа: " + (error instanceof Error ? error.message : "Неизвестная ошибка"),
            )
          }
        }
      },
    )
  }

  const handleView = (doc: Document) => {
    window.location.href = `/doc/${doc.id}`
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const handleCreateDocument = () => {
    // Переключиться на вкладку создания
    window.dispatchEvent(new CustomEvent("changeTab", { detail: "create" }))
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-blue-50 text-blue-700 border-blue-200"
      case "completed":
        return "bg-green-50 text-green-700 border-green-200"
      case "rejected":
        return "bg-red-50 text-red-700 border-red-200"
      case "draft":
        return "bg-gray-50 text-gray-700 border-gray-200"
      default:
        return "bg-gray-50 text-gray-700 border-gray-200"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "В работе"
      case "completed":
        return "Завершён"
      case "rejected":
        return "Отклонён"
      case "draft":
        return "Черновик"
      default:
        return status
    }
  }

  const getTypeLabel = (type: string) => {
    return type === "tz" ? "ТЗ" : "Бриф"
  }

  const statusTabs = [
    { id: "active" as StatusFilter, label: "Активные", count: documents.filter((d) => d.status === "active").length },
    {
      id: "completed" as StatusFilter,
      label: "Завершённые",
      count: documents.filter((d) => d.status === "completed").length,
    },
    { id: "draft" as StatusFilter, label: "Черновики", count: documents.filter((d) => d.status === "draft").length },
    { id: "templates" as StatusFilter, label: "Шаблоны", count: documents.filter((d) => d.is_template).length },
  ]

  // Error state
  if (error && !loading) {
    return (
      <div className="mobile-card p-6 text-center">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="h-8 w-8 text-red-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Ошибка загрузки</h3>
        <p className="text-sm text-gray-600 mb-4">{error}</p>
        <button onClick={fetchDocuments} className="mobile-button mobile-button-primary">
          Попробовать снова
        </button>
      </div>
    )
  }

  // Loading state
  if (loading) {
    return (
      <div className="space-y-3">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="mobile-card mobile-skeleton p-4">
            <div className="flex items-start space-x-3">
              <div className="w-12 h-12 bg-gray-200 rounded-lg flex-shrink-0"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/4"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Status Tabs */}
      <div className="flex space-x-1 bg-gray-50 p-1 rounded-xl">
        {statusTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setStatusFilter(tab.id)
              webApp?.HapticFeedback?.selectionChanged()
            }}
            className={`flex-1 px-2 py-2 text-xs font-medium rounded-lg transition-all duration-200 touch-feedback ${
              statusFilter === tab.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
            }`}
          >
            <div className="text-center">
              <div className="truncate">{tab.label}</div>
              {tab.count > 0 && <div className="text-xs opacity-60">({tab.count})</div>}
            </div>
          </button>
        ))}
      </div>

      {/* Simplified Filters */}
      <div className="flex items-center justify-between gap-3">
        <div className="relative flex-1">
          <select
            value={sortOrder}
            onChange={(e) => {
              setSortOrder(e.target.value as SortOrder)
              webApp?.HapticFeedback?.selectionChanged()
            }}
            className="mobile-input text-sm appearance-none pr-8"
          >
            <option value="newest">Новые → Старые</option>
            <option value="oldest">Старые → Новые</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
        </div>

        <div className="relative flex-1">
          <select
            value={typeFilter}
            onChange={(e) => {
              setTypeFilter(e.target.value as TypeFilter)
              webApp?.HapticFeedback?.selectionChanged()
            }}
            className="mobile-input text-sm appearance-none pr-8"
          >
            <option value="all">Все типы</option>
            <option value="tz">ТЗ</option>
            <option value="brief">Бриф</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
        </div>
      </div>

      {/* Documents List */}
      {documents.length === 0 ? (
        <div className="mobile-card p-8 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileText className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Нет документов</h3>
          <p className="text-sm text-gray-600 mb-6">
            {statusFilter === "active" && "У вас пока нет активных документов"}
            {statusFilter === "completed" && "У вас пока нет завершённых документов"}
            {statusFilter === "draft" && "У вас пока нет черновиков"}
            {statusFilter === "templates" && "У вас пока нет шаблонов"}
          </p>
          <div className="flex justify-center">
            <button onClick={handleCreateDocument} className="mobile-button mobile-button-primary px-8">
              <Plus className="h-4 w-4 mr-2" />
              Создать документ
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {documents.map((doc) => (
            <div key={doc.id} className="mobile-card p-4 touch-feedback cursor-pointer" onClick={() => handleView(doc)}>
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1 min-w-0">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center flex-shrink-0">
                    {doc.preview_image ? (
                      <img
                        src={doc.preview_image || "/placeholder.svg"}
                        alt="Preview"
                        className="w-full h-full object-cover rounded-lg"
                      />
                    ) : (
                      <FileText className={`h-6 w-6 ${doc.type === "tz" ? "text-blue-600" : "text-purple-600"}`} />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="outline" className="text-xs font-medium">
                        {getTypeLabel(doc.type)}
                      </Badge>
                      <Badge className={`text-xs border ${getStatusColor(doc.status)}`}>
                        {getStatusLabel(doc.status)}
                      </Badge>
                      {doc.is_template && (
                        <Badge variant="secondary" className="text-xs">
                          Шаблон
                        </Badge>
                      )}
                    </div>

                    <h3 className="font-semibold text-gray-900 mb-1 truncate text-sm">{doc.title}</h3>

                    <div className="flex items-center text-xs text-gray-500">
                      <Calendar className="h-3 w-3 mr-1 flex-shrink-0" />
                      <span className="truncate">
                        {new Date(doc.updated_at).toLocaleDateString("ru-RU", {
                          day: "numeric",
                          month: "short",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-1 ml-2 flex-shrink-0">
                  <button
                    onClick={(e) => handleShare(doc, e)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 touch-feedback"
                  >
                    <Share className="h-4 w-4 text-gray-500" />
                  </button>
                  <button
                    onClick={(e) => handleDelete(doc, e)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-50 touch-feedback"
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {shareModalOpen && selectedDocument && (
        <ShareModal
          document={selectedDocument}
          isOpen={shareModalOpen}
          onClose={() => {
            setShareModalOpen(false)
            setSelectedDocument(null)
          }}
        />
      )}
    </div>
  )
}
