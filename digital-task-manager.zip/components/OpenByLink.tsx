"use client"

import { useState } from "react"
import { Link, Search, AlertCircle, Info } from "lucide-react"
import { useTelegram } from "@/components/providers/TelegramProvider"

export function OpenByLink() {
  const [url, setUrl] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { webApp } = useTelegram()

  const handleOpen = async () => {
    if (!url.trim()) {
      setError("Введите ссылку на документ")
      return
    }

    const linkPattern = /^https:\/\/tma\.astrum\.app\/doc\/[a-zA-Z0-9-]+$/
    if (!linkPattern.test(url)) {
      setError("Неверный формат ссылки")
      return
    }

    setLoading(true)
    setError("")
    webApp?.HapticFeedback?.impactOccurred("light")

    try {
      const docId = url.split("/").pop()
      const response = await fetch(`/api/documents/${docId}`)
      const data = await response.json()

      if (response.ok) {
        webApp?.HapticFeedback?.notificationOccurred("success")
        window.location.href = `/doc/${docId}`
      } else {
        setError(data.error || "Документ не найден")
        webApp?.HapticFeedback?.notificationOccurred("error")
      }
    } catch (err) {
      setError("Ошибка при открытии документа")
      webApp?.HapticFeedback?.notificationOccurred("error")
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (value: string) => {
    setUrl(value)
    if (error) setError("")
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-2xl flex items-center justify-center">
          <Link className="h-8 w-8 text-blue-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Открыть по ссылке</h2>
        <p className="text-sm text-gray-600">Введите ссылку на документ для просмотра</p>
      </div>

      {/* Input Form */}
      <div className="mobile-card p-4 space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Ссылка на документ</label>
          <input
            type="url"
            placeholder="https://tma.astrum.app/doc/..."
            value={url}
            onChange={(e) => handleInputChange(e.target.value)}
            className={`mobile-input ${error ? "border-red-300" : ""}`}
          />
          {error && (
            <div className="flex items-center mt-2 text-sm text-red-600">
              <AlertCircle className="h-4 w-4 mr-1 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        <button
          onClick={handleOpen}
          disabled={loading || !url.trim()}
          className={`mobile-button w-full ${
            loading || !url.trim() ? "bg-gray-300 text-gray-500" : "mobile-button-primary"
          }`}
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
              Открываем...
            </>
          ) : (
            <>
              <Search className="h-4 w-4 mr-2" />
              Открыть документ
            </>
          )}
        </button>
      </div>

      {/* Examples */}
      <div className="mobile-card p-4 space-y-3">
        <h4 className="text-sm font-medium text-gray-700">Примеры ссылок</h4>
        <div className="space-y-2">
          <div className="p-3 bg-gray-50 rounded-lg">
            <code className="text-xs text-gray-800 break-all">https://tma.astrum.app/doc/abc123</code>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <code className="text-xs text-gray-800 break-all">https://tma.astrum.app/doc/xyz-456-def</code>
          </div>
        </div>
      </div>

      {/* Help */}
      <div className="mobile-card p-4 bg-blue-50 border-blue-200">
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
            <Info className="h-4 w-4 text-blue-600" />
          </div>
          <div>
            <h4 className="font-medium text-blue-900 mb-1 text-sm">Как получить ссылку?</h4>
            <p className="text-xs text-blue-800">
              Ссылка создается при отправке документа через бота. Также её можно скопировать из меню документа.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
