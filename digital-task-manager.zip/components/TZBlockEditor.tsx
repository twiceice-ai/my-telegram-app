"use client"

import { useState } from "react"
import { ImageIcon, Video, Link, Plus, Trash2, X } from "lucide-react"
import { useTelegram } from "@/components/providers/TelegramProvider"

interface TZBlock {
  id: string
  type: "media" | "description" | "tasks" | "references"
  title: string
  content: any
  order: number
}

interface TZBlockEditorProps {
  block: TZBlock
  onUpdate: (updates: Partial<TZBlock>) => void
  onDelete: () => void
}

export function TZBlockEditor({ block, onUpdate, onDelete }: TZBlockEditorProps) {
  const [expanded, setExpanded] = useState(true)
  const { webApp } = useTelegram()

  const handleMediaUpload = async (type: "image" | "video") => {
    try {
      const input = document.createElement("input")
      input.type = "file"
      input.accept = type === "image" ? "image/*" : "video/*"
      input.onchange = async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0]
        if (!file) return

        // Проверяем размер файла
        if (file.size > 4.5 * 1024 * 1024) {
          webApp?.showAlert("Файл слишком большой. Максимальный размер: 4.5 МБ")
          return
        }

        webApp?.HapticFeedback?.impactOccurred("light")
        webApp?.MainButton.setText("Загружаем...")
        webApp?.MainButton.showProgress()

        try {
          const formData = new FormData()
          formData.append("file", file)
          formData.append("type", "media")

          const response = await fetch("/api/upload", {
            method: "POST",
            body: formData,
          })

          const data = await response.json()

          if (response.ok) {
            const currentMedia = block.content.media || []
            onUpdate({
              content: {
                ...block.content,
                media: [...currentMedia, { type, url: data.url, caption: "" }],
              },
            })
            webApp?.HapticFeedback?.notificationOccurred("success")
          } else {
            throw new Error(data.error || "Ошибка загрузки")
          }
        } catch (error) {
          console.error("Upload error:", error)
          webApp?.HapticFeedback?.notificationOccurred("error")
          webApp?.showAlert("Ошибка загрузки файла")
        } finally {
          webApp?.MainButton.hideProgress()
          webApp?.MainButton.hide()
        }
      }
      input.click()
    } catch (error) {
      console.error("Error creating file input:", error)
    }
  }

  const addTask = () => {
    const currentTasks = block.content.tasks || []
    onUpdate({
      content: {
        ...block.content,
        tasks: [...currentTasks, ""],
      },
    })
  }

  const updateTask = (index: number, value: string) => {
    const currentTasks = [...(block.content.tasks || [])]
    currentTasks[index] = value
    onUpdate({
      content: {
        ...block.content,
        tasks: currentTasks,
      },
    })
  }

  const removeTask = (index: number) => {
    const currentTasks = block.content.tasks?.filter((_: any, i: number) => i !== index) || []
    onUpdate({
      content: {
        ...block.content,
        tasks: currentTasks,
      },
    })
  }

  const addReference = (type: "image" | "link") => {
    const currentRefs = block.content.references || []
    onUpdate({
      content: {
        ...block.content,
        references: [...currentRefs, { type, url: "", title: "" }],
      },
    })
  }

  const updateReference = (index: number, updates: any) => {
    const currentRefs = [...(block.content.references || [])]
    currentRefs[index] = { ...currentRefs[index], ...updates }
    onUpdate({
      content: {
        ...block.content,
        references: currentRefs,
      },
    })
  }

  const removeReference = (index: number) => {
    const currentRefs = block.content.references?.filter((_: any, i: number) => i !== index) || []
    onUpdate({
      content: {
        ...block.content,
        references: currentRefs,
      },
    })
  }

  const removeMedia = (index: number) => {
    const currentMedia = block.content.media?.filter((_: any, i: number) => i !== index) || []
    onUpdate({
      content: {
        ...block.content,
        media: currentMedia,
      },
    })
  }

  const renderBlockContent = () => {
    switch (block.type) {
      case "media":
        return (
          <div className="space-y-3">
            {/* Media Items */}
            {block.content.media?.map((item: any, index: number) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700 flex items-center">
                    {item.type === "image" ? (
                      <ImageIcon className="h-4 w-4 mr-2" />
                    ) : (
                      <Video className="h-4 w-4 mr-2" />
                    )}
                    {item.type === "image" ? "Изображение" : "Видео"}
                  </span>
                  <button
                    onClick={() => removeMedia(index)}
                    className="w-6 h-6 flex items-center justify-center rounded hover:bg-red-100 touch-feedback"
                  >
                    <X className="h-3 w-3 text-red-500" />
                  </button>
                </div>
                {item.type === "image" ? (
                  <img src={item.url || "/placeholder.svg"} alt="Media" className="w-full h-32 object-cover rounded" />
                ) : (
                  <video src={item.url} className="w-full h-32 object-cover rounded" controls />
                )}
                <input
                  type="text"
                  placeholder="Описание (необязательно)"
                  value={item.caption || ""}
                  onChange={(e) => {
                    const currentMedia = [...(block.content.media || [])]
                    currentMedia[index] = { ...currentMedia[index], caption: e.target.value }
                    onUpdate({
                      content: {
                        ...block.content,
                        media: currentMedia,
                      },
                    })
                  }}
                  className="mobile-input text-sm mt-2"
                />
              </div>
            )) || []}

            {/* Add Media Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleMediaUpload("image")}
                className="mobile-button mobile-button-secondary text-sm"
              >
                <ImageIcon className="h-4 w-4 mr-2" />
                Добавить фото
              </button>
              <button
                onClick={() => handleMediaUpload("video")}
                className="mobile-button mobile-button-secondary text-sm"
              >
                <Video className="h-4 w-4 mr-2" />
                Добавить видео
              </button>
            </div>
          </div>
        )

      case "description":
        return (
          <textarea
            placeholder="Опишите суть проекта, цели и задачи..."
            value={block.content.description || ""}
            onChange={(e) =>
              onUpdate({
                content: {
                  ...block.content,
                  description: e.target.value,
                },
              })
            }
            className="mobile-input min-h-[100px] resize-none text-sm"
          />
        )

      case "tasks":
        return (
          <div className="space-y-3">
            {block.content.tasks?.map((task: string, index: number) => (
              <div key={index} className="flex space-x-2">
                <input
                  type="text"
                  placeholder={`Задача ${index + 1}`}
                  value={task}
                  onChange={(e) => updateTask(index, e.target.value)}
                  className="mobile-input flex-1 text-sm"
                />
                {(block.content.tasks?.length || 0) > 1 && (
                  <button
                    onClick={() => removeTask(index)}
                    className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-red-50 touch-feedback"
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </button>
                )}
              </div>
            )) || []}
            <button onClick={addTask} className="mobile-button mobile-button-secondary w-full text-sm">
              <Plus className="h-4 w-4 mr-2" />
              Добавить задачу
            </button>
          </div>
        )

      case "references":
        return (
          <div className="space-y-3">
            {block.content.references?.map((reference: any, index: number) => (
              <div key={index} className="space-y-2 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700 flex items-center">
                    {reference.type === "image" ? (
                      <ImageIcon className="h-4 w-4 mr-2" />
                    ) : (
                      <Link className="h-4 w-4 mr-2" />
                    )}
                    {reference.type === "image" ? "Изображение" : "Ссылка"}
                  </span>
                  <button
                    onClick={() => removeReference(index)}
                    className="w-6 h-6 flex items-center justify-center rounded hover:bg-red-100 touch-feedback"
                  >
                    <Trash2 className="h-3 w-3 text-red-500" />
                  </button>
                </div>
                <input
                  type="text"
                  placeholder={reference.type === "image" ? "URL изображения" : "URL ссылки"}
                  value={reference.url}
                  onChange={(e) => updateReference(index, { url: e.target.value })}
                  className="mobile-input text-sm"
                />
                <input
                  type="text"
                  placeholder="Описание (необязательно)"
                  value={reference.title || ""}
                  onChange={(e) => updateReference(index, { title: e.target.value })}
                  className="mobile-input text-sm"
                />
              </div>
            )) || []}
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => addReference("image")} className="mobile-button mobile-button-secondary text-sm">
                <ImageIcon className="h-4 w-4 mr-2" />
                Изображение
              </button>
              <button onClick={() => addReference("link")} className="mobile-button mobile-button-secondary text-sm">
                <Link className="h-4 w-4 mr-2" />
                Ссылка
              </button>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="border border-gray-200 rounded-lg">
      {/* Block Header */}
      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-t-lg">
        <h4 className="font-medium text-gray-900">{block.title}</h4>
        <button
          onClick={onDelete}
          className="w-6 h-6 flex items-center justify-center rounded hover:bg-red-100 touch-feedback"
        >
          <Trash2 className="h-3 w-3 text-red-500" />
        </button>
      </div>

      {/* Block Content */}
      <div className="p-3">{renderBlockContent()}</div>
    </div>
  )
}
