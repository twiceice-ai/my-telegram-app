"use client"

import { useState, useEffect } from "react"
import { Palette, Type, ImageIcon, Upload, X } from "lucide-react"
import { useTelegram } from "@/components/providers/TelegramProvider"

interface DesignConfig {
  background: { type: "color" | "image"; value: string }
  logo?: string
  logoPosition?: "left" | "center" | "right"
  font: string
}

interface DesignStepProps {
  design: DesignConfig
  onDesignChange: (design: DesignConfig) => void
  title: string
  onTitleChange: (title: string) => void
  placeholder: string
}

export function DesignStep({ design, onDesignChange, title, onTitleChange, placeholder }: DesignStepProps) {
  const [activeSection, setActiveSection] = useState<"background" | "logo" | "font" | null>(null)
  const [googleFonts, setGoogleFonts] = useState<string[]>([])
  const [loadingFonts, setLoadingFonts] = useState(false)
  const { webApp } = useTelegram()

  const backgroundColors = [
    "#f8fafc", // slate-50
    "#f0f9ff", // sky-50
    "#ecfdf5", // emerald-50
    "#fef3c7", // amber-50
    "#fce7f3", // pink-50
    "#f3e8ff", // violet-50
    "#fff7ed", // orange-50
    "#f0fdf4", // green-50
  ]

  const popularGoogleFonts = [
    "Inter",
    "Roboto",
    "Open Sans",
    "Lato",
    "Montserrat",
    "Poppins",
    "Source Sans Pro",
    "Nunito",
    "Ubuntu",
    "PT Sans",
    "Oswald",
    "Raleway",
  ]

  useEffect(() => {
    loadGoogleFonts()
  }, [])

  const loadGoogleFonts = async () => {
    setLoadingFonts(true)
    try {
      // Используем только системные шрифты и предзагруженные Google Fonts
      setGoogleFonts(["Inter", "Roboto", "Open Sans", ...popularGoogleFonts])
    } catch (error) {
      console.error("Error loading Google Fonts:", error)
      // Fallback к системным шрифтам
      setGoogleFonts(["Inter", "Roboto", "Open Sans", "System Default"])
    } finally {
      setLoadingFonts(false)
    }
  }

  const handleBackgroundColorChange = (color: string) => {
    onDesignChange({
      ...design,
      background: { type: "color", value: color },
    })
    webApp?.HapticFeedback?.selectionChanged()
  }

  const handleFontChange = (font: string) => {
    onDesignChange({
      ...design,
      font,
    })
    webApp?.HapticFeedback?.selectionChanged()
  }

  const handleImageUpload = async (type: "background" | "logo") => {
    try {
      // Создаем input для выбора файла
      const input = document.createElement("input")
      input.type = "file"
      input.accept = "image/*"
      input.onchange = async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0]
        if (!file) return

        if (file.size > 4.5 * 1024 * 1024) {
          webApp?.showAlert("Файл слишком большой. Максимальный размер: 4.5 МБ")
          return
        }

        webApp?.HapticFeedback?.impactOccurred("light")

        // Показываем индикатор загрузки
        webApp?.MainButton.setText("Загружаем...")
        webApp?.MainButton.showProgress()

        try {
          const formData = new FormData()
          formData.append("file", file)
          formData.append("type", type)

          const response = await fetch("/api/upload", {
            method: "POST",
            body: formData,
          })

          const data = await response.json()

          if (response.ok) {
            if (type === "background") {
              onDesignChange({
                ...design,
                background: { type: "image", value: data.url },
              })
            } else if (type === "logo") {
              onDesignChange({
                ...design,
                logo: data.url,
              })
            }
            webApp?.HapticFeedback?.notificationOccurred("success")
          } else {
            throw new Error(data.error || "Ошибка загрузки")
          }
        } catch (error) {
          console.error("Upload error:", error)
          webApp?.HapticFeedback?.notificationOccurred("error")
          webApp?.showAlert("Ошибка загрузки файла")
        } finally {
          webApp?.MainButton.hideProgress()
          webApp?.MainButton.hide()
        }
      }
      input.click()
    } catch (error) {
      console.error("Error creating file input:", error)
    }
  }

  return (
    <div className="space-y-4">
      {/* Title Input */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">Название</label>
        <input
          type="text"
          placeholder={placeholder}
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          className="mobile-input font-medium"
        />
      </div>

      {/* Background */}
      <div className="mobile-card p-4">
        <button
          onClick={() => setActiveSection(activeSection === "background" ? null : "background")}
          className="w-full flex items-center justify-between touch-feedback"
        >
          <div className="flex items-center">
            <Palette className="h-5 w-5 text-gray-600 mr-3" />
            <div className="text-left">
              <h3 className="font-medium text-gray-900">Фон</h3>
              <p className="text-sm text-gray-600">
                {design.background.type === "color" ? "Цветная заливка" : "Изображение"}
              </p>
            </div>
          </div>
          <div
            className="w-8 h-8 rounded-lg border-2 border-gray-200"
            style={{
              backgroundColor: design.background.type === "color" ? design.background.value : "#f3f4f6",
              backgroundImage: design.background.type === "image" ? `url(${design.background.value})` : undefined,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          ></div>
        </button>

        {activeSection === "background" && (
          <div className="mt-4 space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Цвет фона</h4>
              <div className="grid grid-cols-4 gap-2">
                {backgroundColors.map((color) => (
                  <button
                    key={color}
                    onClick={() => handleBackgroundColorChange(color)}
                    className={`w-full h-12 rounded-lg border-2 transition-all touch-feedback ${
                      design.background.type === "color" && design.background.value === color
                        ? "border-blue-500 scale-105"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                    style={{ backgroundColor: color }}
                  ></button>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Или загрузить изображение</h4>
              <button
                onClick={() => handleImageUpload("background")}
                className="w-full mobile-button mobile-button-secondary"
              >
                <Upload className="h-4 w-4 mr-2" />
                Загрузить изображение
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Logo */}
      <div className="mobile-card p-4">
        <button
          onClick={() => setActiveSection(activeSection === "logo" ? null : "logo")}
          className="w-full flex items-center justify-between touch-feedback"
        >
          <div className="flex items-center">
            <ImageIcon className="h-5 w-5 text-gray-600 mr-3" />
            <div className="text-left">
              <h3 className="font-medium text-gray-900">Логотип</h3>
              <p className="text-sm text-gray-600">{design.logo ? "Загружен" : "Не добавлен"}</p>
            </div>
          </div>
          {design.logo && (
            <button
              onClick={(e) => {
                e.stopPropagation()
                onDesignChange({ ...design, logo: undefined })
              }}
              className="w-6 h-6 flex items-center justify-center rounded hover:bg-red-100 touch-feedback"
            >
              <X className="h-3 w-3 text-red-500" />
            </button>
          )}
        </button>

        {activeSection === "logo" && (
          <div className="mt-4">
            <button onClick={() => handleImageUpload("logo")} className="w-full mobile-button mobile-button-secondary">
              <Upload className="h-4 w-4 mr-2" />
              Загрузить логотип
            </button>
            <p className="text-xs text-gray-500 mt-2">Рекомендуемый размер: 200x200px</p>
            {design.logo && (
              <div className="mt-3">
                <label className="block text-sm font-medium text-gray-700 mb-2">Позиция логотипа</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: "left", label: "Слева" },
                    { value: "center", label: "По центру" },
                    { value: "right", label: "Справа" },
                  ].map((position) => (
                    <button
                      key={position.value}
                      onClick={() =>
                        onDesignChange({
                          ...design,
                          logoPosition: position.value,
                        })
                      }
                      className={`p-2 rounded-lg border-2 transition-colors touch-feedback text-xs ${
                        (design.logoPosition || "center") === position.value
                          ? "border-blue-500 bg-blue-50 text-blue-700"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      {position.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Font */}
      <div className="mobile-card p-4">
        <button
          onClick={() => setActiveSection(activeSection === "font" ? null : "font")}
          className="w-full flex items-center justify-between touch-feedback"
        >
          <div className="flex items-center">
            <Type className="h-5 w-5 text-gray-600 mr-3" />
            <div className="text-left">
              <h3 className="font-medium text-gray-900">Шрифт</h3>
              <p className="text-sm text-gray-600">{design.font}</p>
            </div>
          </div>
        </button>

        {activeSection === "font" && (
          <div className="mt-4 space-y-2 max-h-60 overflow-y-auto">
            {loadingFonts ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500 mx-auto"></div>
                <p className="text-sm text-gray-500 mt-2">Загрузка шрифтов...</p>
              </div>
            ) : (
              googleFonts.map((font) => (
                <button
                  key={font}
                  onClick={() => handleFontChange(font)}
                  className={`w-full p-3 text-left rounded-lg border transition-colors touch-feedback ${
                    design.font === font
                      ? "border-blue-500 bg-blue-50 text-blue-700"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  style={{
                    fontFamily: font.startsWith("Avenir")
                      ? font.includes("Light")
                        ? "Avenir, sans-serif"
                        : font.includes("Bold")
                          ? "Avenir, sans-serif"
                          : "Avenir, sans-serif"
                      : `"${font}", sans-serif`,
                    fontWeight: font.includes("Light") ? 300 : font.includes("Bold") ? 700 : 400,
                  }}
                >
                  {font}
                </button>
              ))
            )}
          </div>
        )}
      </div>

      {/* Preview */}
      <div className="mobile-card p-4">
        <h3 className="font-medium text-gray-900 mb-3">Предварительный просмотр</h3>
        <div
          className="w-full h-32 rounded-lg border-2 border-gray-200 flex items-center justify-center overflow-hidden"
          style={{
            backgroundColor: design.background.type === "color" ? design.background.value : "#f3f4f6",
            backgroundImage: design.background.type === "image" ? `url(${design.background.value})` : undefined,
            backgroundSize: "cover",
            backgroundPosition: "center",
            fontFamily:
              design.font === "Inter"
                ? "var(--font-primary)"
                : design.font === "Roboto"
                  ? "var(--font-secondary)"
                  : design.font === "Open Sans"
                    ? "var(--font-display)"
                    : `"${design.font}", -apple-system, BlinkMacSystemFont, sans-serif`,
            color: "#1f2937",
            WebkitTextFillColor: "#1f2937",
          }}
        >
          <div className="text-center p-3">
            {design.logo && (
              <div
                className={`mb-2 flex ${
                  design.logoPosition === "left"
                    ? "justify-start"
                    : design.logoPosition === "right"
                      ? "justify-end"
                      : "justify-center"
                }`}
              >
                <img src={design.logo || "/placeholder.svg"} alt="Logo" className="w-8 h-8 rounded" />
              </div>
            )}
            <h4 className="font-semibold text-gray-900 text-sm">{title || placeholder}</h4>
          </div>
        </div>
      </div>
    </div>
  )
}
