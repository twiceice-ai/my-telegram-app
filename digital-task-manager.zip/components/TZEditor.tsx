"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, ArrowRight, Plus, GripVertical, ChevronDown, ChevronRight, Trash2, Eye } from "lucide-react"
import { useTelegram } from "@/components/providers/TelegramProvider"
import { DesignStep } from "@/components/DesignStep"
import { ShareModal } from "@/components/ShareModal"
import { TZBlockEditor } from "@/components/TZBlockEditor"
import { TZPreview } from "@/components/TZPreview"

interface TZBlock {
  id: string
  type: "media" | "description" | "tasks" | "references"
  title: string
  content: any
  order: number
}

interface TZStep {
  id: string
  title: string
  blocks: TZBlock[]
  order: number
}

interface TZData {
  title: string
  design: {
    background: { type: "color" | "image"; value: string }
    logo?: string
    logoPosition?: "left" | "center" | "right"
    font: string
  }
  steps: TZStep[]
}

interface TZEditorProps {
  onBack: () => void
}

export function TZEditor({ onBack }: TZEditorProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1)
  const [tzData, setTZData] = useState<TZData>({
    title: "",
    design: {
      background: { type: "color", value: "#f8fafc" },
      font: "Avenir Regular",
      logoPosition: "center",
    },
    steps: [
      {
        id: "step-1",
        title: "Шаг 1",
        blocks: [],
        order: 1,
      },
    ],
  })
  const [shareModalOpen, setShareModalOpen] = useState(false)
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set(["step-1"]))
  const [saving, setSaving] = useState(false)
  const [hasContent, setHasContent] = useState(false)
  const { webApp, user, initData } = useTelegram()

  const blockTypes = [
    { type: "media", title: "Медиафайлы", icon: "📷" },
    { type: "description", title: "Описание проекта", icon: "📝" },
    { type: "tasks", title: "Что нужно сделать", icon: "✅" },
    { type: "references", title: "Референсы", icon: "🔗" },
  ]

  const handleNext = () => {
    if (step === 1) {
      setStep(2)
      webApp?.HapticFeedback?.impactOccurred("light")
    } else if (step === 2) {
      setStep(3)
      webApp?.HapticFeedback?.impactOccurred("light")
    }
  }

  const handlePrevious = () => {
    if (step === 3) {
      setStep(2)
      webApp?.HapticFeedback?.impactOccurred("light")
    } else if (step === 2) {
      setStep(1)
      webApp?.HapticFeedback?.impactOccurred("light")
    } else {
      onBack()
    }
  }

  const addStep = () => {
    const newStep: TZStep = {
      id: `step-${Date.now()}`,
      title: `Шаг ${tzData.steps.length + 1}`,
      blocks: [],
      order: tzData.steps.length + 1,
    }
    setTZData((prev) => ({
      ...prev,
      steps: [...prev.steps, newStep],
    }))
    setExpandedSteps((prev) => new Set([...prev, newStep.id]))
    webApp?.HapticFeedback?.impactOccurred("light")
  }

  const deleteStep = (stepId: string) => {
    if (tzData.steps.length <= 1) {
      webApp?.showAlert("Нельзя удалить последний шаг")
      return
    }

    setTZData((prev) => ({
      ...prev,
      steps: prev.steps.filter((s) => s.id !== stepId),
    }))
    setExpandedSteps((prev) => {
      const newSet = new Set(prev)
      newSet.delete(stepId)
      return newSet
    })
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const addBlockToStep = (stepId: string, blockType: string) => {
    const newBlock: TZBlock = {
      id: `block-${Date.now()}`,
      type: blockType as TZBlock["type"],
      title: blockTypes.find((bt) => bt.type === blockType)?.title || "",
      content: {},
      order: tzData.steps.find((s) => s.id === stepId)?.blocks.length || 0,
    }

    setTZData((prev) => ({
      ...prev,
      steps: prev.steps.map((step) => (step.id === stepId ? { ...step, blocks: [...step.blocks, newBlock] } : step)),
    }))
    webApp?.HapticFeedback?.impactOccurred("light")
  }

  const updateBlock = (stepId: string, blockId: string, updates: Partial<TZBlock>) => {
    setTZData((prev) => ({
      ...prev,
      steps: prev.steps.map((step) =>
        step.id === stepId
          ? {
              ...step,
              blocks: step.blocks.map((block) => (block.id === blockId ? { ...block, ...updates } : block)),
            }
          : step,
      ),
    }))
  }

  const deleteBlock = (stepId: string, blockId: string) => {
    setTZData((prev) => ({
      ...prev,
      steps: prev.steps.map((step) =>
        step.id === stepId ? { ...step, blocks: step.blocks.filter((block) => block.id !== blockId) } : step,
      ),
    }))
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const toggleStepExpanded = (stepId: string) => {
    setExpandedSteps((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(stepId)) {
        newSet.delete(stepId)
      } else {
        newSet.add(stepId)
      }
      return newSet
    })
    webApp?.HapticFeedback?.selectionChanged()
  }

  const handleSave = async () => {
    if (!tzData.title.trim()) {
      webApp?.showAlert("Введите название ТЗ")
      return
    }

    setSaving(true)
    webApp?.HapticFeedback?.impactOccurred("light")

    try {
      const response = await fetch("/api/documents", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Telegram-Init-Data": initData || "",
        },
        body: JSON.stringify({
          title: tzData.title,
          type: "tz",
          content: {
            steps: tzData.steps,
          },
          design_config: tzData.design,
          user_id: user?.id || 123456789, // Fallback для разработки
        }),
      })

      const data = await response.json()

      if (response.ok) {
        webApp?.HapticFeedback?.notificationOccurred("success")
        webApp?.showAlert("ТЗ сохранено в черновики")
        // Переходим на вкладку документов
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent("changeTab", { detail: "documents" }))
        }, 1000)
      } else {
        throw new Error(data.error || "Ошибка сохранения")
      }
    } catch (error) {
      console.error("Save error:", error)
      webApp?.HapticFeedback?.notificationOccurred("error")
      webApp?.showAlert("Ошибка сохранения документа")
    } finally {
      setSaving(false)
    }
  }

  const handleSend = () => {
    setShareModalOpen(true)
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const mockDocument = {
    id: "tz-" + Date.now(),
    title: tzData.title || "Новое ТЗ",
    type: "tz" as const,
    status: "draft",
  }

  // Отслеживаем изменения в данных для применения фона
  useEffect(() => {
    const hasBlocks = tzData.steps.some((step) => step.blocks.length > 0)
    setHasContent(hasBlocks)
  }, [tzData.steps])

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={handlePrevious} className="mobile-button mobile-button-secondary w-10 h-10 p-0">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="text-center">
          <h2 className="text-lg font-semibold text-gray-900">Создание ТЗ</h2>
          <p className="text-xs text-gray-600">Шаг {step} из 3</p>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress */}
      <div className="flex space-x-2">
        <div className={`flex-1 h-2 rounded-full ${step >= 1 ? "bg-blue-500" : "bg-gray-200"}`}></div>
        <div className={`flex-1 h-2 rounded-full ${step >= 2 ? "bg-blue-500" : "bg-gray-200"}`}></div>
        <div className={`flex-1 h-2 rounded-full ${step >= 3 ? "bg-blue-500" : "bg-gray-200"}`}></div>
      </div>

      {/* Step 1: Design */}
      {step === 1 && (
        <DesignStep
          design={tzData.design}
          onDesignChange={(design) => setTZData((prev) => ({ ...prev, design }))}
          title={tzData.title}
          onTitleChange={(title) => setTZData((prev) => ({ ...prev, title }))}
          placeholder="Название ТЗ"
        />
      )}

      {/* Step 2: Content Steps */}
      {step === 2 && (
        <div
          className="space-y-4 min-h-screen -mx-4 -my-4 px-4 py-4"
          style={
            hasContent
              ? {
                  backgroundColor:
                    tzData.design.background.type === "color" ? tzData.design.background.value : "#ffffff",
                  backgroundImage:
                    tzData.design.background.type === "image" ? `url(${tzData.design.background.value})` : undefined,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  backgroundAttachment: "fixed",
                }
              : {}
          }
        >
          {tzData.steps.map((tzStep) => (
            <div key={tzStep.id} className="mobile-card">
              {/* Step Header */}
              <div className="flex items-center justify-between p-4">
                <button
                  onClick={() => toggleStepExpanded(tzStep.id)}
                  className="flex items-center space-x-3 flex-1 touch-feedback"
                >
                  <GripVertical className="h-4 w-4 text-gray-400" />
                  <div className="text-left">
                    <h3 className="font-semibold text-gray-900">{tzStep.title}</h3>
                    <p className="text-sm text-gray-600">{tzStep.blocks.length} блоков</p>
                  </div>
                  <div className="ml-auto">
                    {expandedSteps.has(tzStep.id) ? (
                      <ChevronDown className="h-5 w-5 text-gray-400" />
                    ) : (
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    )}
                  </div>
                </button>

                {tzData.steps.length > 1 && (
                  <button
                    onClick={() => deleteStep(tzStep.id)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-50 touch-feedback ml-2"
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </button>
                )}
              </div>

              {/* Step Content */}
              {expandedSteps.has(tzStep.id) && (
                <div className="px-4 pb-4 space-y-3">
                  {/* Blocks */}
                  {tzStep.blocks.map((block) => (
                    <TZBlockEditor
                      key={block.id}
                      block={block}
                      onUpdate={(updates) => updateBlock(tzStep.id, block.id, updates)}
                      onDelete={() => deleteBlock(tzStep.id, block.id)}
                    />
                  ))}

                  {/* Add Block Buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    {blockTypes.map((blockType) => (
                      <button
                        key={blockType.type}
                        onClick={() => addBlockToStep(tzStep.id, blockType.type)}
                        className="mobile-card p-3 border-2 border-dashed border-gray-300 hover:border-blue-400 hover:bg-blue-50 transition-colors touch-feedback"
                      >
                        <div className="text-center">
                          <div className="text-lg mb-1">{blockType.icon}</div>
                          <span className="text-xs font-medium text-gray-700">{blockType.title}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Add Step Button */}
          <button
            onClick={addStep}
            className="w-full mobile-card p-4 border-2 border-dashed border-blue-300 text-blue-600 hover:border-blue-400 hover:bg-blue-50 transition-colors touch-feedback"
          >
            <Plus className="h-6 w-6 mx-auto mb-2" />
            <span className="text-sm font-medium">Добавить шаг</span>
          </button>
        </div>
      )}

      {/* Step 3: Preview */}
      {step === 3 && (
        <div
          className="min-h-screen -mx-4 -my-4 px-4 py-4"
          style={{
            backgroundColor: tzData.design.background.type === "color" ? tzData.design.background.value : "#ffffff",
            backgroundImage:
              tzData.design.background.type === "image" ? `url(${tzData.design.background.value})` : undefined,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        >
          <TZPreview tzData={tzData} />
        </div>
      )}

      {/* Actions */}
      <div className="flex space-x-2 pt-4">
        {step === 1 ? (
          <>
            <button onClick={onBack} className="mobile-button mobile-button-secondary flex-1">
              Отмена
            </button>
            <button
              onClick={handleNext}
              disabled={!tzData.title.trim()}
              className={`mobile-button flex-1 ${
                tzData.title.trim() ? "mobile-button-primary" : "bg-gray-300 text-gray-500"
              }`}
            >
              Далее
              <ArrowRight className="h-4 w-4 ml-2" />
            </button>
          </>
        ) : step === 2 ? (
          <>
            <button onClick={handleSave} disabled={saving} className="mobile-button mobile-button-secondary flex-1">
              {saving ? "Сохранение..." : "Сохранить"}
            </button>
            <button
              onClick={handleNext}
              disabled={tzData.steps.every((s) => s.blocks.length === 0)}
              className={`mobile-button flex-1 ${
                tzData.steps.some((s) => s.blocks.length > 0) ? "mobile-button-primary" : "bg-gray-300 text-gray-500"
              }`}
            >
              Предпросмотр
              <Eye className="h-4 w-4 ml-2" />
            </button>
          </>
        ) : (
          <>
            <button onClick={handleSave} disabled={saving} className="mobile-button mobile-button-secondary flex-1">
              {saving ? "Сохранение..." : "Сохранить"}
            </button>
            <button
              onClick={handleSend}
              disabled={tzData.steps.every((s) => s.blocks.length === 0)}
              className={`mobile-button flex-1 ${
                tzData.steps.some((s) => s.blocks.length > 0) ? "mobile-button-primary" : "bg-gray-300 text-gray-500"
              }`}
            >
              Отправить
            </button>
          </>
        )}
      </div>

      {shareModalOpen && (
        <ShareModal document={mockDocument} isOpen={shareModalOpen} onClose={() => setShareModalOpen(false)} />
      )}
    </div>
  )
}
