"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { useTelegram } from "@/components/providers/TelegramProvider"
import { Share, Copy, Send, QrCode, X, User, Check } from "lucide-react"

interface Document {
  id: string
  title: string
  type: "tz" | "brief"
  status: string
}

interface ShareModalProps {
  document: Document
  isOpen: boolean
  onClose: () => void
}

export function ShareModal({ document, isOpen, onClose }: ShareModalProps) {
  const [username, setUsername] = useState("")
  const [sending, setSending] = useState(false)
  const [copied, setCopied] = useState(false)
  const { webApp, initData } = useTelegram()
  const [sendSuccess, setSendSuccess] = useState(false)

  if (!isOpen) return null

  const documentUrl = `https://tma.astrum.app/doc/${document.id}`

  const handleSendToUser = async () => {
    if (!username.trim()) {
      webApp?.showAlert("Введите username получателя")
      return
    }

    setSending(true)
    webApp?.HapticFeedback?.impactOccurred("light")

    try {
      const response = await fetch("/api/send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Telegram-Init-Data": initData,
        },
        body: JSON.stringify({
          username: username.replace("@", ""),
          document_id: document.id,
          document_title: document.title,
          document_type: document.type,
          document_url: documentUrl,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        webApp?.HapticFeedback?.notificationOccurred("success")
        webApp?.showAlert("Документ успешно отправлен!")
        setSendSuccess(true)
        setTimeout(() => setSendSuccess(false), 3000)
        onClose()
      } else {
        webApp?.HapticFeedback?.notificationOccurred("error")
        webApp?.showAlert(data.error || "Ошибка отправки")
      }
    } catch (error) {
      webApp?.HapticFeedback?.notificationOccurred("error")
      webApp?.showAlert("Ошибка отправки документа")
    } finally {
      setSending(false)
    }
  }

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(documentUrl)
      setCopied(true)
      webApp?.HapticFeedback?.notificationOccurred("success")
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      webApp?.showAlert("Не удалось скопировать ссылку")
    }
  }

  const handleGenerateQR = () => {
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(documentUrl)}`
    webApp?.openLink(qrUrl)
  }

  return (
    <div className="mobile-modal">
      <div className="mobile-modal-content">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="flex items-center space-x-2">
            <Share className="h-5 w-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">Поделиться</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 touch-feedback"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-4 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Document Info */}
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-2 mb-1">
              <Badge variant="outline" className="text-xs">
                {document.type === "tz" ? "ТЗ" : "Бриф"}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {document.status}
              </Badge>
            </div>
            <h4 className="font-medium text-gray-900 text-sm truncate">{document.title}</h4>
          </div>

          {/* Send to User */}
          <div className="space-y-3">
            <h4 className="font-medium text-gray-900 flex items-center text-sm">
              <User className="h-4 w-4 mr-2" />
              Отправить пользователю
            </h4>
            <div className="space-y-2">
              <input
                type="text"
                placeholder="@username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="mobile-input text-sm"
                disabled={sending}
              />
              <button
                onClick={handleSendToUser}
                disabled={sending || !username.trim()}
                className={`mobile-button w-full ${
                  sending || !username.trim() ? "bg-gray-300 text-gray-500" : "mobile-button-primary"
                }`}
              >
                {sending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Отправить
                  </>
                )}
              </button>
            </div>
            {sendSuccess && (
              <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-700 text-center">✅ Ссылка отправлена пользователю!</p>
              </div>
            )}
            <p className="text-xs text-gray-500">Документ будет отправлен через Telegram бота с кнопкой для открытия</p>
          </div>

          {/* Copy Link */}
          <div className="space-y-3">
            <h4 className="font-medium text-gray-900 text-sm">Ссылка на документ</h4>
            <div className="space-y-2">
              <input type="text" value={documentUrl} readOnly className="mobile-input text-xs" />
              <button onClick={handleCopyLink} className="mobile-button mobile-button-secondary w-full">
                {copied ? (
                  <>
                    <Check className="h-4 w-4 mr-2 text-green-600" />
                    <span className="text-green-600">Скопировано</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-2" />
                    Копировать ссылку
                  </>
                )}
              </button>
            </div>
          </div>

          {/* QR Code */}
          <div className="space-y-3">
            <h4 className="font-medium text-gray-900 text-sm">QR-код</h4>
            <button onClick={handleGenerateQR} className="mobile-button mobile-button-secondary w-full">
              <QrCode className="h-4 w-4 mr-2" />
              Создать QR-код
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-100">
          <button onClick={onClose} className="mobile-button mobile-button-secondary w-full">
            Закрыть
          </button>
        </div>
      </div>
    </div>
  )
}
