"use client"

import { FileText, ImageIcon, Link, CheckSquare } from "lucide-react"

interface TZBlock {
  id: string
  type: "media" | "description" | "tasks" | "references"
  title: string
  content: any
  order: number
}

interface TZStep {
  id: string
  title: string
  blocks: TZBlock[]
  order: number
}

interface TZData {
  title: string
  design: {
    background: { type: "color" | "image"; value: string }
    logo?: string
    logoPosition?: "left" | "center" | "right"
    font: string
  }
  steps: TZStep[]
}

interface TZPreviewProps {
  tzData: TZData
}

export function TZPreview({ tzData }: TZPreviewProps) {
  const renderBlockContent = (block: TZBlock) => {
    switch (block.type) {
      case "media":
        return (
          <div className="space-y-3">
            {block.content.media?.map((item: any, index: number) => (
              <div key={index} className="space-y-2">
                {item.type === "image" ? (
                  <img
                    src={item.url || "/placeholder.svg"}
                    alt="Media"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                ) : (
                  <video src={item.url} className="w-full h-48 object-cover rounded-lg" controls />
                )}
                {item.caption && <p className="text-sm text-gray-600">{item.caption}</p>}
              </div>
            )) || <p className="text-gray-500 text-sm">Медиафайлы не добавлены</p>}
          </div>
        )

      case "description":
        return (
          <div className="prose prose-sm max-w-none">
            <p className="text-gray-700 whitespace-pre-wrap">{block.content.description || "Описание не добавлено"}</p>
          </div>
        )

      case "tasks":
        return (
          <div className="space-y-2">
            {block.content.tasks?.map((task: string, index: number) => (
              <div key={index} className="flex items-start space-x-2">
                <CheckSquare className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700 text-sm">{task || `Задача ${index + 1}`}</span>
              </div>
            )) || <p className="text-gray-500 text-sm">Задачи не добавлены</p>}
          </div>
        )

      case "references":
        return (
          <div className="space-y-3">
            {block.content.references?.map((ref: any, index: number) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  {ref.type === "image" ? (
                    <ImageIcon className="h-4 w-4 text-gray-500" />
                  ) : (
                    <Link className="h-4 w-4 text-gray-500" />
                  )}
                  <span className="text-sm font-medium text-gray-700">
                    {ref.title || (ref.type === "image" ? "Изображение" : "Ссылка")}
                  </span>
                </div>
                {ref.type === "image" && ref.url && (
                  <img
                    src={ref.url || "/placeholder.svg"}
                    alt="Reference"
                    className="w-full h-32 object-cover rounded"
                  />
                )}
                {ref.url && (
                  <a
                    href={ref.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 text-sm hover:underline break-all"
                  >
                    {ref.url}
                  </a>
                )}
              </div>
            )) || <p className="text-gray-500 text-sm">Референсы не добавлены</p>}
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="space-y-4">
      {/* Preview Header */}
      <div className="text-center mb-6">
        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
          <FileText className="h-6 w-6 text-blue-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Предварительный просмотр</h2>
        <p className="text-sm text-gray-600">Так будет выглядеть ваше ТЗ</p>
      </div>

      {/* Document Preview */}
      <div
        className="mobile-card p-6 space-y-6"
        style={{
          backgroundColor: tzData.design.background.type === "color" ? tzData.design.background.value : "#ffffff",
          backgroundImage:
            tzData.design.background.type === "image" ? `url(${tzData.design.background.value})` : undefined,
          backgroundSize: "cover",
          backgroundPosition: "center",
          fontFamily:
            tzData.design.font === "Inter"
              ? "var(--font-primary)"
              : tzData.design.font === "Roboto"
                ? "var(--font-secondary)"
                : tzData.design.font === "Open Sans"
                  ? "var(--font-display)"
                  : `"${tzData.design.font}", -apple-system, BlinkMacSystemFont, sans-serif`,
          color: "#1f2937",
          WebkitTextFillColor: "#1f2937",
        }}
      >
        {/* Header with Logo */}
        <div className="space-y-4">
          {tzData.design.logo && (
            <div
              className={`flex ${
                tzData.design.logoPosition === "left"
                  ? "justify-start"
                  : tzData.design.logoPosition === "right"
                    ? "justify-end"
                    : "justify-center"
              }`}
            >
              <img src={tzData.design.logo || "/placeholder.svg"} alt="Logo" className="h-12 w-auto" />
            </div>
          )}

          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{tzData.title}</h1>
            <p className="text-sm text-gray-600">Техническое задание</p>
          </div>
        </div>

        {/* Steps Content */}
        {tzData.steps.map((step, stepIndex) => (
          <div key={step.id} className="space-y-4">
            {tzData.steps.length > 1 && (
              <div className="border-t border-gray-200 pt-4">
                <h2 className="text-lg font-semibold text-gray-900 mb-3">{step.title}</h2>
              </div>
            )}

            {step.blocks.map((block) => (
              <div key={block.id} className="space-y-3">
                <h3 className="font-medium text-gray-900 flex items-center">
                  {block.type === "media" && "📷"}
                  {block.type === "description" && "📝"}
                  {block.type === "tasks" && "✅"}
                  {block.type === "references" && "🔗"}
                  <span className="ml-2">{block.title}</span>
                </h3>
                <div className="pl-6">{renderBlockContent(block)}</div>
              </div>
            ))}
          </div>
        ))}

        {/* Footer */}
        <div className="border-t border-gray-200 pt-4 text-center">
          <p className="text-xs text-gray-500">Создано в Astrum • {new Date().toLocaleDateString("ru-RU")}</p>
        </div>
      </div>
    </div>
  )
}
