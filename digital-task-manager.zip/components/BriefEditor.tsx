"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, ArrowRight, Type, ImageIcon, Plus, GripVertical, Trash2, Video, CheckSquare } from "lucide-react"
import { useTelegram } from "@/components/providers/TelegramProvider"
import { DesignStep } from "@/components/DesignStep"
import { ShareModal } from "@/components/ShareModal"

interface Question {
  id: string
  title: string
  subtitle?: string
  type: "text" | "multichoice" | "image" | "video" | "image_choice" | "text_choice"
  options?: string[]
  imageOptions?: { url: string; title: string }[]
  required: boolean
}

interface BriefData {
  title: string
  design: {
    background: { type: "color" | "image"; value: string }
    logo?: string
    banner?: string
    font: string
  }
  questions: Question[]
}

interface BriefEditorProps {
  onBack: () => void
}

export function BriefEditor({ onBack }: BriefEditorProps) {
  const [step, setStep] = useState<1 | 2>(1)
  const [briefData, setBriefData] = useState<BriefData>({
    title: "",
    design: {
      background: { type: "color", value: "#f8fafc" },
      font: "Avenir Regular",
    },
    questions: [],
  })
  const [shareModalOpen, setShareModalOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const { webApp, user, initData } = useTelegram()
  const [hasContent, setHasContent] = useState(false)

  const handleNext = () => {
    if (step === 1) {
      setStep(2)
      webApp?.HapticFeedback?.impactOccurred("light")
    }
  }

  const handlePrevious = () => {
    if (step === 2) {
      setStep(1)
      webApp?.HapticFeedback?.impactOccurred("light")
    } else {
      onBack()
    }
  }

  const addQuestion = () => {
    const newQuestion: Question = {
      id: Date.now().toString(),
      title: "",
      subtitle: "",
      type: "text",
      required: false,
    }
    setBriefData((prev) => ({
      ...prev,
      questions: [...prev.questions, newQuestion],
    }))
    webApp?.HapticFeedback?.impactOccurred("light")
  }

  const updateQuestion = (id: string, updates: Partial<Question>) => {
    setBriefData((prev) => ({
      ...prev,
      questions: prev.questions.map((q) => (q.id === id ? { ...q, ...updates } : q)),
    }))
  }

  const deleteQuestion = (id: string) => {
    setBriefData((prev) => ({
      ...prev,
      questions: prev.questions.filter((q) => q.id !== id),
    }))
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const handleSave = async () => {
    if (!briefData.title.trim()) {
      webApp?.showAlert("Введите название брифа")
      return
    }

    setSaving(true)
    webApp?.HapticFeedback?.impactOccurred("light")

    try {
      const response = await fetch("/api/documents", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Telegram-Init-Data": initData || "",
        },
        body: JSON.stringify({
          title: briefData.title,
          type: "brief",
          content: {
            questions: briefData.questions,
          },
          design_config: briefData.design,
          user_id: user?.id || 123456789, // Fallback для разработки
        }),
      })

      const data = await response.json()

      if (response.ok) {
        webApp?.HapticFeedback?.notificationOccurred("success")
        webApp?.showAlert("Бриф сохранен в черновики")
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent("changeTab", { detail: "documents" }))
        }, 1000)
      } else {
        throw new Error(data.error || "Ошибка сохранения")
      }
    } catch (error) {
      console.error("Save error:", error)
      webApp?.HapticFeedback?.notificationOccurred("error")
      webApp?.showAlert("Ошибка сохранения документа")
    } finally {
      setSaving(false)
    }
  }

  const handleSend = () => {
    setShareModalOpen(true)
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const mockDocument = {
    id: "brief-" + Date.now(),
    title: briefData.title || "Новый бриф",
    type: "brief" as const,
    status: "draft",
  }

  // Отслеживаем изменения в данных для применения фона
  useEffect(() => {
    setHasContent(briefData.questions.length > 0)
  }, [briefData.questions])

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={handlePrevious} className="mobile-button mobile-button-secondary w-10 h-10 p-0">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="text-center">
          <h2 className="text-lg font-semibold text-gray-900">Создание брифа</h2>
          <p className="text-xs text-gray-600">Шаг {step} из 2</p>
        </div>
        <div className="w-10"></div>
      </div>

      {/* Progress */}
      <div className="flex space-x-2">
        <div className={`flex-1 h-2 rounded-full ${step >= 1 ? "bg-purple-500" : "bg-gray-200"}`}></div>
        <div className={`flex-1 h-2 rounded-full ${step >= 2 ? "bg-purple-500" : "bg-gray-200"}`}></div>
      </div>

      {/* Step 1: Design */}
      {step === 1 && (
        <DesignStep
          design={briefData.design}
          onDesignChange={(design) => setBriefData((prev) => ({ ...prev, design }))}
          title={briefData.title}
          onTitleChange={(title) => setBriefData((prev) => ({ ...prev, title }))}
          placeholder="Название брифа"
        />
      )}

      {/* Step 2: Questions */}
      {step === 2 && (
        <div
          className="space-y-4 min-h-screen -mx-4 -my-4 px-4 py-4"
          style={
            hasContent
              ? {
                  backgroundColor:
                    briefData.design.background.type === "color" ? briefData.design.background.value : "#ffffff",
                  backgroundImage:
                    briefData.design.background.type === "image"
                      ? `url(${briefData.design.background.value})`
                      : undefined,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  backgroundAttachment: "fixed",
                }
              : {}
          }
        >
          <div className="mobile-card p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Вопросы брифа</h3>

            {briefData.questions.length === 0 ? (
              <div className="text-center py-8">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Plus className="h-6 w-6 text-purple-600" />
                </div>
                <p className="text-sm text-gray-600 mb-4">Добавьте первый вопрос</p>
                <button onClick={addQuestion} className="mobile-button mobile-button-primary">
                  <Plus className="h-4 w-4 mr-2" />
                  Добавить вопрос
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {briefData.questions.map((question, index) => (
                  <QuestionEditor
                    key={question.id}
                    question={question}
                    index={index}
                    onUpdate={(updates) => updateQuestion(question.id, updates)}
                    onDelete={() => deleteQuestion(question.id)}
                  />
                ))}

                {/* Add Question Button */}
                <button
                  onClick={addQuestion}
                  className="w-full mobile-card p-4 border-2 border-dashed border-purple-300 text-purple-600 hover:border-purple-400 hover:bg-purple-50 transition-colors touch-feedback"
                >
                  <Plus className="h-6 w-6 mx-auto mb-2" />
                  <span className="text-sm font-medium">Добавить вопрос</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex space-x-2 pt-4">
        {step === 1 ? (
          <>
            <button onClick={onBack} className="mobile-button mobile-button-secondary flex-1">
              Отмена
            </button>
            <button
              onClick={handleNext}
              disabled={!briefData.title.trim()}
              className={`mobile-button flex-1 ${
                briefData.title.trim() ? "mobile-button-primary" : "bg-gray-300 text-gray-500"
              }`}
            >
              Далее
              <ArrowRight className="h-4 w-4 ml-2" />
            </button>
          </>
        ) : (
          <>
            <button onClick={handleSave} disabled={saving} className="mobile-button mobile-button-secondary flex-1">
              {saving ? "Сохранение..." : "Сохранить"}
            </button>
            <button
              onClick={handleSend}
              disabled={briefData.questions.length === 0}
              className={`mobile-button flex-1 ${
                briefData.questions.length > 0 ? "mobile-button-primary" : "bg-gray-300 text-gray-500"
              }`}
            >
              Отправить
            </button>
          </>
        )}
      </div>

      {/* Share Modal */}
      {shareModalOpen && (
        <ShareModal document={mockDocument} isOpen={shareModalOpen} onClose={() => setShareModalOpen(false)} />
      )}
    </div>
  )
}

interface QuestionEditorProps {
  question: Question
  index: number
  onUpdate: (updates: Partial<Question>) => void
  onDelete: () => void
}

function QuestionEditor({ question, index, onUpdate, onDelete }: QuestionEditorProps) {
  const { webApp } = useTelegram()

  const questionTypes = [
    { value: "text", label: "Текст", icon: Type },
    { value: "text_choice", label: "Текст выбор", icon: CheckSquare },
    { value: "image_choice", label: "Картинки", icon: ImageIcon },
    { value: "multichoice", label: "Множественный", icon: CheckSquare },
    { value: "image", label: "Изображение", icon: ImageIcon },
    { value: "video", label: "Видео", icon: Video },
  ]

  const addOption = () => {
    const newOptions = [...(question.options || []), ""]
    onUpdate({ options: newOptions })
  }

  const updateOption = (optionIndex: number, value: string) => {
    const newOptions = [...(question.options || [])]
    newOptions[optionIndex] = value
    onUpdate({ options: newOptions })
  }

  const removeOption = (optionIndex: number) => {
    const newOptions = question.options?.filter((_, i) => i !== optionIndex) || []
    onUpdate({ options: newOptions })
  }

  const addImageOption = () => {
    const newImageOptions = [...(question.imageOptions || []), { url: "", title: "" }]
    onUpdate({ imageOptions: newImageOptions })
  }

  const updateImageOption = (optionIndex: number, updates: Partial<{ url: string; title: string }>) => {
    const newImageOptions = [...(question.imageOptions || [])]
    newImageOptions[optionIndex] = { ...newImageOptions[optionIndex], ...updates }
    onUpdate({ imageOptions: newImageOptions })
  }

  const removeImageOption = (optionIndex: number) => {
    const newImageOptions = question.imageOptions?.filter((_, i) => i !== optionIndex) || []
    onUpdate({ imageOptions: newImageOptions })
  }

  const handleImageUpload = async (optionIndex: number) => {
    try {
      const input = document.createElement("input")
      input.type = "file"
      input.accept = "image/*"
      input.onchange = async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0]
        if (!file) return

        if (file.size > 4.5 * 1024 * 1024) {
          webApp?.showAlert("Файл слишком большой. Максимальный размер: 4.5 МБ")
          return
        }

        webApp?.HapticFeedback?.impactOccurred("light")
        webApp?.MainButton.setText("Загружаем...")
        webApp?.MainButton.showProgress()

        try {
          const formData = new FormData()
          formData.append("file", file)
          formData.append("type", "question_image")

          const response = await fetch("/api/upload", {
            method: "POST",
            body: formData,
          })

          const data = await response.json()

          if (response.ok) {
            updateImageOption(optionIndex, { url: data.url })
            webApp?.HapticFeedback?.notificationOccurred("success")
          } else {
            throw new Error(data.error || "Ошибка загрузки")
          }
        } catch (error) {
          console.error("Upload error:", error)
          webApp?.HapticFeedback?.notificationOccurred("error")
          webApp?.showAlert("Ошибка загрузки файла")
        } finally {
          webApp?.MainButton.hideProgress()
          webApp?.MainButton.hide()
        }
      }
      input.click()
    } catch (error) {
      console.error("Error creating file input:", error)
    }
  }

  return (
    <div className="mobile-card p-4 space-y-4">
      {/* Question Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <GripVertical className="h-4 w-4 text-gray-400" />
          <span className="text-sm font-medium text-gray-600">Вопрос {index + 1}</span>
        </div>
        <button
          onClick={onDelete}
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-50 touch-feedback"
        >
          <Trash2 className="h-4 w-4 text-red-500" />
        </button>
      </div>

      {/* Question Title */}
      <div>
        <input
          type="text"
          placeholder="Заголовок вопроса"
          value={question.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
          className="mobile-input text-sm font-medium"
        />
      </div>

      {/* Question Subtitle */}
      <div>
        <input
          type="text"
          placeholder="Подзаголовок (необязательно)"
          value={question.subtitle || ""}
          onChange={(e) => onUpdate({ subtitle: e.target.value })}
          className="mobile-input text-sm"
        />
      </div>

      {/* Question Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Тип ответа</label>
        <div className="grid grid-cols-3 gap-2">
          {questionTypes.map((type) => {
            const Icon = type.icon
            return (
              <button
                key={type.value}
                onClick={() => {
                  onUpdate({ type: type.value as Question["type"] })
                  webApp?.HapticFeedback?.selectionChanged()
                }}
                className={`p-2 rounded-lg border-2 transition-colors touch-feedback ${
                  question.type === type.value
                    ? "border-purple-500 bg-purple-50 text-purple-700"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <Icon className="h-3 w-3 mx-auto mb-1" />
                <span className="text-xs font-medium">Выбор</span>
              </button>
            )
          })}
        </div>
      </div>

      {/* Text Choice Options */}
      {question.type === "text_choice" && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Варианты текста</label>
          <div className="space-y-2">
            {question.options?.map((option, optionIndex) => (
              <div key={optionIndex} className="flex space-x-2">
                <input
                  type="text"
                  placeholder={`Вариант ${optionIndex + 1}`}
                  value={option}
                  onChange={(e) => updateOption(optionIndex, e.target.value)}
                  className="mobile-input flex-1 text-sm"
                />
                <button
                  onClick={() => removeOption(optionIndex)}
                  className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-red-50 touch-feedback"
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </button>
              </div>
            )) || []}
            <button onClick={addOption} className="w-full mobile-button mobile-button-secondary text-sm">
              <Plus className="h-4 w-4 mr-2" />
              Добавить вариант
            </button>
          </div>
        </div>
      )}

      {/* Image Choice Options */}
      {question.type === "image_choice" && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Варианты с картинками</label>
          <div className="space-y-3">
            {question.imageOptions?.map((option, optionIndex) => (
              <div key={optionIndex} className="p-3 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">Вариант {optionIndex + 1}</span>
                  <button
                    onClick={() => removeImageOption(optionIndex)}
                    className="w-6 h-6 flex items-center justify-center rounded hover:bg-red-100 touch-feedback"
                  >
                    <Trash2 className="h-3 w-3 text-red-500" />
                  </button>
                </div>

                {/* Image Preview */}
                {option.url ? (
                  <div className="relative">
                    <img
                      src={option.url || "/placeholder.svg"}
                      alt="Option"
                      className="w-full h-24 object-cover rounded"
                    />
                    <button
                      onClick={() => updateImageOption(optionIndex, { url: "" })}
                      className="absolute top-1 right-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => handleImageUpload(optionIndex)}
                    className="w-full h-24 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center hover:border-purple-400 hover:bg-purple-50 transition-colors touch-feedback"
                  >
                    <div className="text-center">
                      <ImageIcon className="h-6 w-6 mx-auto mb-1 text-gray-400" />
                      <span className="text-xs text-gray-500">Загрузить изображение</span>
                    </div>
                  </button>
                )}

                {/* Title Input */}
                <input
                  type="text"
                  placeholder="Название варианта"
                  value={option.title}
                  onChange={(e) => updateImageOption(optionIndex, { title: e.target.value })}
                  className="mobile-input text-sm"
                />
              </div>
            )) || []}
            <button onClick={addImageOption} className="w-full mobile-button mobile-button-secondary text-sm">
              <Plus className="h-4 w-4 mr-2" />
              Добавить вариант с картинкой
            </button>
          </div>
        </div>
      )}

      {/* Multiple Choice Options */}
      {question.type === "multichoice" && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Варианты ответов</label>
          <div className="space-y-2">
            {question.options?.map((option, optionIndex) => (
              <div key={optionIndex} className="flex space-x-2">
                <input
                  type="text"
                  placeholder={`Вариант ${optionIndex + 1}`}
                  value={option}
                  onChange={(e) => updateOption(optionIndex, e.target.value)}
                  className="mobile-input flex-1 text-sm"
                />
                <button
                  onClick={() => removeOption(optionIndex)}
                  className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-red-50 touch-feedback"
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </button>
              </div>
            )) || []}
            <button onClick={addOption} className="w-full mobile-button mobile-button-secondary text-sm">
              <Plus className="h-4 w-4 mr-2" />
              Добавить вариант
            </button>
          </div>
        </div>
      )}

      {/* Required Toggle */}
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-gray-700">Обязательный вопрос</span>
        <button
          onClick={() => {
            onUpdate({ required: !question.required })
            webApp?.HapticFeedback?.selectionChanged()
          }}
          className={`w-12 h-6 rounded-full transition-colors ${question.required ? "bg-purple-500" : "bg-gray-300"}`}
        >
          <div
            className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${
              question.required ? "translate-x-6" : "translate-x-0.5"
            }`}
          ></div>
        </button>
      </div>
    </div>
  )
}
