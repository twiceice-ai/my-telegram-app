"use client"

import { useState } from "react"
import { FileText, MessageSquare, ArrowRight, Sparkles } from "lucide-react"
import { useTelegram } from "@/components/providers/TelegramProvider"
import { BriefEditor } from "@/components/BriefEditor"
import { TZEditor } from "@/components/TZEditor"

type DocumentType = "tz" | "brief"

export function CreateDocument() {
  const [selectedType, setSelectedType] = useState<DocumentType | null>(null)
  const { webApp } = useTelegram()

  const handleTypeSelect = (type: DocumentType) => {
    setSelectedType(type)
    webApp?.HapticFeedback?.impactOccurred("medium")
  }

  const handleBack = () => {
    setSelectedType(null)
    webApp?.HapticFeedback?.impactOccurred("light")
  }

  if (selectedType === "brief") {
    return <BriefEditor onBack={handleBack} />
  }

  if (selectedType === "tz") {
    return <TZEditor onBack={handleBack} />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center">
          <Sparkles className="h-8 w-8 text-white" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Создать документ</h2>
        <p className="text-sm text-gray-600">Выберите тип документа для создания</p>
      </div>

      {/* Document Type Cards */}
      <div className="space-y-3">
        {/* ТЗ Card */}
        <div className="mobile-card p-4 cursor-pointer touch-feedback" onClick={() => handleTypeSelect("tz")}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div className="min-w-0">
                <h3 className="font-semibold text-gray-900">Техническое задание</h3>
                <p className="text-xs text-gray-600">Подробное описание проекта</p>
              </div>
            </div>
            <ArrowRight className="h-5 w-5 text-gray-400 flex-shrink-0" />
          </div>

          <div className="space-y-1 text-xs text-gray-600">
            <div className="flex items-center">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
              Описание проекта и целей
            </div>
            <div className="flex items-center">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
              Список задач и требований
            </div>
            <div className="flex items-center">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
              Референсы и примеры
            </div>
          </div>
        </div>

        {/* Бриф Card */}
        <div className="mobile-card p-4 cursor-pointer touch-feedback" onClick={() => handleTypeSelect("brief")}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <MessageSquare className="h-6 w-6 text-purple-600" />
              </div>
              <div className="min-w-0">
                <h3 className="font-semibold text-gray-900">Бриф</h3>
                <p className="text-xs text-gray-600">Опросник для клиента</p>
              </div>
            </div>
            <ArrowRight className="h-5 w-5 text-gray-400 flex-shrink-0" />
          </div>

          <div className="space-y-1 text-xs text-gray-600">
            <div className="flex items-center">
              <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2"></div>
              Конструктор вопросов
            </div>
            <div className="flex items-center">
              <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2"></div>
              Разные типы ответов
            </div>
            <div className="flex items-center">
              <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2"></div>
              Настраиваемый дизайн
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
