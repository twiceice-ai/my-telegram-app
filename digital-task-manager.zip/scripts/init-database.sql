CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Создание таблицы документов
CREATE TABLE IF NOT EXISTS documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id BIGINT NOT NULL,
  title VARCHAR(100) NOT NULL,
  type VARCHAR(10) CHECK (type IN ('tz', 'brief')) NOT NULL,
  status VARCHAR(20) CHECK (status IN ('draft', 'active', 'completed', 'rejected')) DEFAULT 'draft',
  design_config JSONB DEFAULT '{}',
  content JSONB DEFAULT '{}',
  is_template BOOLEAN DEFAULT false,
  preview_image TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Создание индексов для оптимизации запросов
CREATE INDEX IF NOT EXISTS idx_documents_user_id ON documents(user_id);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(type);
CREATE INDEX IF NOT EXISTS idx_documents_updated_at ON documents(updated_at);
CREATE INDEX IF NOT EXISTS idx_documents_is_template ON documents(is_template);

-- Создание функции для автоматического обновления updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Создание триггера для автоматического обновления updated_at
DROP TRIGGER IF EXISTS update_documents_updated_at ON documents;
CREATE TRIGGER update_documents_updated_at
    BEFORE UPDATE ON documents
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Вставка тестовых данных
INSERT INTO documents (user_id, title, type, status, content, design_config) VALUES
(123456789, 'ТЗ для лендинга интернет-магазина', 'tz', 'active', 
 '{"description": "Создать современный лендинг для продажи товаров", "tasks": ["Дизайн главной страницы", "Форма заказа", "Интеграция с CRM"]}',
 '{"bgColor": "#f8fafc", "font": "Avenir Regular"}'),
(123456789, 'Бриф для ребрендинга компании', 'brief', 'draft',
 '{"questions": [{"title": "Опишите текущую ситуацию", "type": "text", "required": true}]}',
 '{"bgColor": "#fef3c7", "font": "Avenir Bold"}'),
(123456789, 'ТЗ мобильного приложения', 'tz', 'completed',
 '{"description": "Разработка iOS/Android приложения", "tasks": ["UI/UX дизайн", "Разработка", "Тестирование"]}',
 '{"bgColor": "#dcfce7", "font": "Avenir Light"}')
ON CONFLICT DO NOTHING;
