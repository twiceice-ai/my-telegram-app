CREATE TABLE IF NOT EXISTS documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id BIGINT NOT NULL,
  title VARCHAR(100) NOT NULL,
  type VARCHAR(10) NOT NULL CHECK (type IN ('tz', 'brief')),
  status VARCHAR(10) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'completed')),
  design_config JSONB,
  content JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Создание индексов для оптимизации запросов
CREATE INDEX IF NOT EXISTS idx_documents_user_id ON documents(user_id);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(type);
CREATE INDEX IF NOT EXISTS idx_documents_updated_at ON documents(updated_at);
CREATE INDEX IF NOT EXISTS idx_documents_is_template ON documents(is_template);

-- Создание функции для автоматического обновления updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Создание триггера для автоматического обновления updated_at
DROP TRIGGER IF EXISTS update_documents_updated_at ON documents;
CREATE TRIGGER update_documents_updated_at
    BEFORE UPDATE ON documents
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Вставка тестовых данных
INSERT INTO documents (user_id, title, type, status, content, design_config) VALUES
(123456789, 'ТЗ для лендинга интернет-магазина', 'tz', 'active', 
 '{"description": "Создать современный лендинг для продажи товаров", "tasks": ["Дизайн главной страницы", "Форма заказа", "Интеграция с CRM"]}',
 '{"background": {"type": "color", "value": "#f8fafc"}, "font": "Avenir Regular"}'),
(123456789, 'Бриф для ребрендинга компании', 'brief', 'draft',
 '{"questions": [{"title": "Опишите текущую ситуацию", "type": "text", "required": true}]}',
 '{"background": {"type": "color", "value": "#fef3c7"}, "font": "Avenir Bold"}'),
(123456789, 'ТЗ мобильного приложения', 'tz', 'completed',
 '{"description": "Разработка iOS/Android приложения", "tasks": ["UI/UX дизайн", "Разработка", "Тестирование"]}',
 '{"background": {"type": "color", "value": "#dcfce7"}, "font": "Avenir Light"}')
ON CONFLICT DO NOTHING;
