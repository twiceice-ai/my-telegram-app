import { neon } from "@neondatabase/serverless"

// Check for available database URLs
const getDatabaseUrl = () => {
  const urls = [process.env.DATABASE_URL, process.env.POSTGRES_URL, process.env.DATABASE_URL_UNPOOLED]

  for (const url of urls) {
    if (url) {
      console.log("Using database URL:", url.substring(0, 20) + "...")
      return url
    }
  }

  throw new Error("No database URL found in environment variables")
}

let sql: ReturnType<typeof neon>

try {
  const databaseUrl = getDatabaseUrl()
  sql = neon(databaseUrl)
} catch (error) {
  console.error("Failed to initialize database connection:", error)
  throw error
}

export async function safeQuery(query: string, params: any[] = []) {
  try {
    console.log("Executing query:", query)
    console.log("With params:", params)

    const result = await sql(query, params)
    console.log("Query result:", result)
    return { data: result, error: null }
  } catch (error) {
    console.error("Database query error:", error)

    // More detailed error information
    const errorDetails = {
      message: error instanceof Error ? error.message : "Unknown database error",
      name: error instanceof Error ? error.name : "UnknownError",
      stack: error instanceof Error ? error.stack : undefined,
      query,
      params,
    }

    return {
      data: null,
      error: errorDetails,
    }
  }
}

// Test database connection
export async function testConnection() {
  try {
    console.log("Testing database connection...")
    const result = await sql`SELECT 1 as test`
    console.log("Database connection test successful:", result)
    return { success: true, result }
  } catch (error) {
    console.error("Database connection test failed:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Connection test failed",
    }
  }
}

// Initialize database tables if they don't exist
export async function initializeDatabase() {
  console.log("Initializing database tables...")

  // First test the connection
  const connectionTest = await testConnection()
  if (!connectionTest.success) {
    throw new Error(`Database connection failed: ${connectionTest.error}`)
  }

  // Create UUID extension
  const createUuidExtension = `CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`

  // Updated documents table with new structure
  const createDocumentsTable = `
    CREATE TABLE IF NOT EXISTS documents (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id BIGINT NOT NULL,
      title VARCHAR(100) NOT NULL,
      type VARCHAR(10) NOT NULL CHECK (type IN ('tz', 'brief')),
      status VARCHAR(10) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'completed')),
      design_config JSONB,
      content JSONB,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `

  const createTasksTable = `
    CREATE TABLE IF NOT EXISTS tasks (
      id SERIAL PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      status VARCHAR(50) DEFAULT 'pending',
      priority VARCHAR(20) DEFAULT 'medium',
      due_date TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `

  try {
    // Create UUID extension
    const { error: uuidError } = await safeQuery(createUuidExtension)
    if (uuidError) {
      console.warn("UUID extension creation warning:", uuidError)
      // Continue anyway as extension might already exist
    }

    // Create documents table
    const { error: docsError } = await safeQuery(createDocumentsTable)
    if (docsError) {
      throw new Error(`Failed to create documents table: ${JSON.stringify(docsError)}`)
    }

    // Create tasks table
    const { error: tasksError } = await safeQuery(createTasksTable)
    if (tasksError) {
      throw new Error(`Failed to create tasks table: ${JSON.stringify(tasksError)}`)
    }

    console.log("Database tables initialized successfully")
    return { success: true }
  } catch (error) {
    console.error("Failed to initialize database:", error)
    throw error
  }
}
